# Normal600 B compatibility Evidence successor

Pure data coordination. The frozen 201 source files, original GRR schema, two shared-input kinds, 19 tests and independent assessment rules remain unchanged. No SQL, signature, host call, budget reservation or new case result is produced here.

The entry first calls the exact original assembler. It then appends three precisely bound independent reports as ordinary, non-test artifacts: the accepted B response contract, its historical installation readback, and the actual post-terminal restoration readback. Their digests enter the existing input digest list and raw Evidence references. Original decision/test/observation bytes are preserved. The complete final index and escaped PostgreSQL request must still fit 131072 bytes; oversized data is rejected without truncation.

The historical installation report does not establish the database identity for a new GA. ExactSources.json must bind the actual received restoration report before this helper can produce an assembly. It must not claim that all original 14 function bytes remain identical: the accepted B wrapper remains changed, while the original execution_transition is restored. Normal fresh SQL admission and terminal CAS remain mandatory.

Use the original assembly input, adding `b_compatibility_evidence` with exactly `compatibility`, `installation`, `restoration`; each value is `{raw, sha256}` containing the complete unchanged report bytes. Preserve every existing assessment and source observation. Do not place these reports in `shared_artifacts` or label them as PQUAL observations.

Run from the workspace with the actual input/output paths under qualification-live-preparation:

```
node work/qualification-live-preparation/b-evidence-successor/assemble-with-b.mjs reservation ACTUAL_INPUT.json NEW_OUTPUT.json
```

The reservation input retains `{assembly_input, idempotency_key, expected_sequence}`. The output retains the original `{assembly, request, size}` shape and may be consumed by the unchanged prepare-grr.mjs after actual reservation/SIGNING readback. This command creates data only; it never executes the request. No GA ID or time is generated in advance.

The unrelated denial-input history size issue is not solved by these attachments. A changed compression envelope cannot be passed off as compatible with the frozen DEFLATE_V1 decoder.
