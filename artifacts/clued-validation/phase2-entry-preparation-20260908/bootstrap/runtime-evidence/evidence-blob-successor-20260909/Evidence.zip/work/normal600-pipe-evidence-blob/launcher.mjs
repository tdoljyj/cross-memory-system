import fs from 'node:fs';import path from 'node:path';import {fileURLToPath} from 'node:url';import {spawn} from 'node:child_process';import readline from 'node:readline';import {archiveAndSend} from './deliver.mjs';
const dir=path.dirname(fileURLToPath(import.meta.url)),work=path.resolve(dir,'..'),[ga,op]=process.argv.slice(2);
if(process.argv.length!==4||!/^ga_[a-f0-9]{32}$/.test(ga)||!['CREATE','START','GRR'].includes(op))throw Error('FIXED_GA_OPERATION_ONLY');
if(process.execPath.replaceAll('\\','/').toLowerCase()!=='c:/program files/nodejs/node.exe')throw Error('FIXED_NODE');
const prefix=path.join(work,'qualification-live',ga+'.'+op+'.blob-pipe600');fs.mkdirSync(prefix);
const fd=fs.openSync(prefix+'.stdout.raw','wx');
const child=spawn(process.execPath,[path.join(dir,'ready-loader.mjs')],{cwd:path.join(work,'kernel-phase2-repo'),stdio:['pipe',fd,'inherit'],env:{...process.env,NODE_OPTIONS:'',NODE_PATH:''},windowsHide:true});
// Console carries only short fixed notices. Full actual messages never traverse it.
if(process.stdin.isTTY)process.stdin.setRawMode(true);
const lines=readline.createInterface({input:process.stdin,crlfDelay:Infinity,terminal:false});let sequence=1,failed=false,finished=false;
function fail(e){if(failed)return;failed=true;process.stderr.write('PIPE600_UNKNOWN '+String(e.message)+'\n');lines.close();child.stdin.destroy();child.kill();process.exitCode=1;}
lines.on('line',line=>{try{
 if(failed||finished||line.length>160)throw Error('NO_ADDITIONAL_INPUT');
 const notice=JSON.parse(line),delivered=sequence;
 archiveAndSend(prefix,notice,sequence,child.stdin,error=>{if(error)return fail(error);process.stderr.write(JSON.stringify({state:'PIPE600_BYTES_WRITTEN',sequence:delivered,bytes:notice.bytes,sha256:notice.sha256})+'\n');});sequence++;
 }catch(e){fail(e);}});
child.once('error',fail);child.once('exit',(code,signal)=>{finished=true;fs.fsyncSync(fd);fs.closeSync(fd);lines.close();process.stdin.pause();process.exitCode=!failed&&code===0&&signal===null?0:1;});
