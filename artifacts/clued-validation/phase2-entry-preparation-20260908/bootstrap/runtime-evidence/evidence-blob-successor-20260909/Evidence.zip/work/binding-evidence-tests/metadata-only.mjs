// Reuses the existing disposable PG setup; only new remote-evidence checks follow.
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import fs from 'node:fs/promises';
import net from 'node:net';
import os from 'node:os';
import path from 'node:path';
import {createRequire} from 'node:module';
import {fileURLToPath} from 'node:url';
import test from 'node:test';
import {createBudgetStore as createExecutionStore,projectRef,rootId} from '../kernel-phase2-repo/scripts/phase2-qualification/nonproduction-control-store/runtime-successor/budget-reservation-successor/client.mjs';
import {checkDispatchEvidence} from '../kernel-phase2-repo/scripts/phase2-qualification/control-context-verifier-runtime180/dispatch-evidence.mjs';
import {recordQuery,dispatchQuery} from '../kernel-phase2-repo/scripts/phase2-qualification/control-context-verifier-runtime180/transport.mjs';
const evidence={kind:'LOCAL_SYNTHETIC_FORWARD_BINDING_COMPONENT_NOT_AUTHORITY',started_at:new Date().toISOString(),observations:[]};
const keep=(label,value)=>{evidence.observations.push({label,observed_at:new Date().toISOString(),value});};
const require=createRequire(new URL('../kernel-phase2-repo/apps/clued-cloud/package.json',import.meta.url));
const EmbeddedPostgres=require('embedded-postgres').default;
const directory=path.dirname(fileURLToPath(import.meta.url));
const sha=raw=>crypto.createHash('sha256').update(raw).digest('hex');
const h='a'.repeat(64),gen='ctrgen_352785779b64458a889d571360e2d2d5',container='c'.repeat(64);
async function port(){const s=net.createServer();await new Promise(r=>s.listen(0,'127.0.0.1',r));const value=s.address().port;await new Promise(r=>s.close(r));return value;}

test('actual private forward binding projection; synthetic metadata, no authority or host',{timeout:180000},async t=>{
 const dir=await fs.mkdtemp(path.join(directory,'pg-data-'));
 const server=new EmbeddedPostgres({databaseDir:dir,user:'postgres',password:crypto.randomBytes(32).toString('hex'),port:await port(),persistent:false,postgresFlags:['-c','io_method=sync'],onLog(){},onError(m){process.stderr.write(m+'\n');}});
 const clients=[];
 try{
  await server.initialise();await server.start();const admin=server.getPgClient();clients.push(admin);await admin.connect();
  await admin.query('create role anon nologin;create role authenticated nologin;create role service_role nologin bypassrls;create table public.legacy_sentinel(value text);insert into public.legacy_sentinel values(\'unchanged\');');
  const oldSql=await fs.readFile(path.join(directory,'../kernel-phase2-repo/scripts/phase2-qualification/nonproduction-control-store/install.candidate.sql'),'utf8');
  const sql=await fs.readFile(path.join(directory,'../kernel-phase2-repo/scripts/phase2-qualification/nonproduction-control-store/runtime-successor/budget-reservation-successor/install.candidate.sql'),'utf8');
  await assert.rejects(admin.query(sql),/wrong_or_missing_existing_control_domain/);
  await admin.query("set clued_control.target_project='uscrdifznmlvczcekqpw'");await admin.query(oldSql);
  const privileges=(await admin.query("select oid::regprocedure::text name,proacl::text,prosecdef,proconfig from pg_proc where pronamespace='clued_control'::regnamespace order by name")).rows;
  await admin.query(sql.replaceAll('\r\n','\n'));
  const oldNames=privileges.map(x=>x.name);
  assert.deepEqual((await admin.query("select oid::regprocedure::text name,proacl::text,prosecdef,proconfig from pg_proc where pronamespace='clued_control'::regnamespace order by name")).rows.filter(x=>oldNames.includes(x.name)),privileges);
  const connect=async role=>{const c=server.getPgClient();clients.push(c);await c.connect();await c.query('set role '+role);return c;};
  const writer=await connect('service_role'),other=await connect('service_role');
  const store=createExecutionStore({project:projectRef,query:writer.query.bind(writer)}),store2=createExecutionStore({project:projectRef,query:other.query.bind(other)});
  // Synthetic metadata is injected only into this throwaway database by its admin.
  // G1 here tests string binding; it is NOT a proposed applicable pre-entry Gate.
  await admin.query(`insert into clued_control.accepted_binding values($1,$2,'SKILL_COEXISTENCE_QUALIFICATION','ISOLATED_TEST',
   'e4ab25ecb1fa6709435d0318ad431d14343482cbe84e232f638e55c3c4ba1e1f','4d7f93c17cf7d126e771cf8aca6299c868cba0a9',
   clock_timestamp()-interval '1 minute',least(clock_timestamp()+interval '10 minutes','2026-09-09T09:28:59Z'),
   'SYNTHETIC_ISSUER','SYNTHETIC_AUDIENCE','SYNTHETIC_CONFIG',$3,$3,$3,$3,$3)`,[rootId,projectRef,h]);
  await admin.query('insert into clued_control.current_head values($1,1,$2,false)',[rootId,gen]);
  await admin.query("insert into clued_control.execution_binding values($1,$2,$2,$2,$2,'G-PREENTRY-SKILL-QUALIFICATION','SYNTHETIC_DEFINITION_NOT_ACCEPTED',$2,$2,1410,19264968)",[rootId,h]);
  await admin.query("insert into clued_control.execution_current values($1,'runner-initial','credential-initial','session-initial',0,null,null,1410,19264968)",[rootId]);
  const makeGa=key=>{const now=Date.now();return {gate_authorization_id:'ga_'+key,idempotency_key:key,authorization_status:'AUTHORIZED',purpose:'SKILL_COEXISTENCE_QUALIFICATION',environment:'ISOLATED_TEST',
   profile_digest:h,controller_digest:h,scope_digest:h,gate_id:'G-PREENTRY-SKILL-QUALIFICATION',controller_qualification_ref:{sha256:h},control_trust_root_generation:gen,
   runner_generation:'runner-initial',credential_generation:'credential-initial',session_generation:'session-initial',
   issued_at:new Date(now-1000).toISOString(),deadline:new Date(now+60000).toISOString(),expires_at:new Date(now+60000).toISOString()};};


  const sm={object_type:'StatusManifest',schema_version:'1.0',schema_digest:'6ba12ed51b3fc0e457c13e83f47e1ad1aa6cc680d8f28c668f8c65d12742ecc2',
   status_manifest_id:'sm_budget',issuer_purpose:'STATUS',audience:'urn:clued:audience:skill-coexistence-qualification:uscrdifznmlvczcekqpw',
   control_trust_root_generation:gen,generation:1,as_of:new Date(Date.now()-1000).toISOString(),expires_at:new Date(Date.now()+300000).toISOString(),signature_binding:{synthetic_only:true}};
  const smRaw=JSON.stringify(sm)+'\n';await store.appendStatus(smRaw);
  const allocation=key=>({controller_digest:h,credential_generation:'credential-initial',environment:'ISOLATED_TEST',evidence_bytes:134217728,
   expires_at:new Date(Date.now()+300000).toISOString(),idempotency_key:key,not_before:new Date(Date.now()-1000).toISOString(),profile_digest:h,
   purpose:'SKILL_COEXISTENCE_QUALIFICATION',root_generation:gen,runner_generation:'runner-initial',scope_digest:h,seconds:180,session_generation:'session-initial'});
  const gaFor=(key,ref)=>({...makeGa(key),issued_at:new Date(Date.now()-100).toISOString(),
   status_manifest_ref:{uri:'control://status-manifests/sm_budget',sha256:sha(smRaw)},budget_reservation_ref:ref});
  const runtimeDir=path.join(directory,'../kernel-phase2-repo/scripts/phase2-qualification/nonproduction-control-store/runtime-successor');
  const old600=await fs.readFile(path.join(runtimeDir,'runtime600-successor/alter.candidate.sql'),'utf8');
  await admin.query(old600.slice(old600.indexOf('create or replace function')));
  const oldState=await store.read(),securitySql="select proname,prosrc,proacl::text,prosecdef,proconfig from pg_proc where pronamespace='clued_control'::regnamespace order by proname";
  const priorFunctions=(await admin.query(securitySql)).rows;
  const candidate=await fs.readFile(path.join(runtimeDir,'binding-evidence-successor/alter.candidate.sql'),'utf8');
  await admin.query(candidate);
  assert.deepEqual(await store.read(),oldState);
  const afterFunctions=(await admin.query(securitySql)).rows;
  for(const f of priorFunctions){const next=afterFunctions.find(x=>x.proname===f.proname);for(const k of ['proacl','prosecdef','proconfig'])assert.deepEqual(next[k],f[k]);if(!['read_execution','reserve_execution_budget','reserve_gate'].includes(f.proname))assert.deepEqual(next,f);}
  for(const role of ['anon','authenticated','service_role'])assert.equal((await admin.query("select has_function_privilege($1,'clued_control.effective_execution_binding()','EXECUTE') allowed",[role])).rows[0].allowed,false);
  keep('install_no_data_change',{candidate_sha256:sha(candidate),before:oldState,after:await store.read(),priorFunctions,afterFunctions});
  const definitions=(await admin.query("select proname name,pg_get_functiondef(oid) definition,prosrc,proacl::text acl,prosecdef security_definer,proconfig config,pg_get_userbyid(proowner) owner from pg_proc where pronamespace='clued_control'::regnamespace and proname in ('effective_execution_binding','read_execution','reserve_execution_budget','reserve_gate') order by proname")).rows;
  await fs.writeFile(path.join(directory,'FunctionDefinitions.json'),JSON.stringify({kind:'ACTUAL_LOCAL_PG_METADATA_ONLY_NOT_DEPLOYED',observed_at:new Date().toISOString(),functions:definitions},null,2)+'\n',{flag:'wx'});
 }finally{await Promise.all(clients.map(c=>c.end().catch(()=>{})));await server.stop();}
});
