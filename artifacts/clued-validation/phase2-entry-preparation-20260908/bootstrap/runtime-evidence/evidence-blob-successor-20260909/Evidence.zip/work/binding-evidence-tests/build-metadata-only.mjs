import fs from 'node:fs';
let source=fs.readFileSync('work/binding-evidence-tests/integration.test.mjs','utf8');source=source.slice(0,source.indexOf('  const successor='));
source+=`  const definitions=(await admin.query("select proname name,pg_get_functiondef(oid) definition,prosrc,proacl::text acl,prosecdef security_definer,proconfig config,pg_get_userbyid(proowner) owner from pg_proc where pronamespace='clued_control'::regnamespace and proname in ('effective_execution_binding','read_execution','reserve_execution_budget','reserve_gate') order by proname")).rows;
  await fs.writeFile(path.join(directory,'FunctionDefinitions.json'),JSON.stringify({kind:'ACTUAL_LOCAL_PG_METADATA_ONLY_NOT_DEPLOYED',observed_at:new Date().toISOString(),functions:definitions},null,2)+'\\n',{flag:'wx'});
 }finally{await Promise.all(clients.map(c=>c.end().catch(()=>{})));await server.stop();}
});
`;
fs.writeFileSync('work/binding-evidence-tests/metadata-only.mjs',source,{flag:'wx'});
