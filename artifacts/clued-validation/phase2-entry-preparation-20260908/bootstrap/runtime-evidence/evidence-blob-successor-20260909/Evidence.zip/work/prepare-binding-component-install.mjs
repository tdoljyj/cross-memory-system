// Pure exact-byte preparation; does not contact services or change bindings.
import fs from 'node:fs';
import crypto from 'node:crypto';
import {isDeepStrictEqual as same} from 'node:util';
import {snapshotQuery} from './kernel-phase2-repo/scripts/phase2-qualification/runtime-database-alignment-successor/prepare-restoration.mjs';
const sha=x=>crypto.createHash('sha256').update(x).digest('hex'),need=(x,m)=>{if(!x)throw Error(m);};
const read=p=>fs.readFileSync(p,'utf8'),current=JSON.parse(read('work/binding-component-preimage.json'));
const dir='work/kernel-phase2-repo/scripts/phase2-qualification/nonproduction-control-store/runtime-successor/binding-evidence-successor/';
const patch=read(dir+'alter.candidate.sql'),impact=JSON.parse(read(dir+'Impact.json'));
const metadataRaw=read('work/binding-evidence-tests/FunctionDefinitions.json'),metadata=JSON.parse(metadataRaw);
need(sha(patch)==='bd94bd2c40a1f3d7703316ec58296e2e07faeb00b1d5055c3ca64000db59d847','EXACT_ACCEPTED_SQL');
need(sha(metadataRaw)==='27f3e076aaa62a46aecb93341f2c79dfa858c871b6f557b8a89e303d0682ddf6','EXACT_ACTUAL_LOCAL_PG_DEFINITIONS');
const view=x=>{const y=structuredClone(x);delete y.observed_at;delete y.transition_definition;return y;};
need(same(view(current),view(JSON.parse(read('work/qualification-live/next-normal600/recovery-restored-readback.json')))),'ACTUAL_FULL_RESTORED_PREIMAGE_UNCHANGED');
need(current.functions.length===14&&current.tables.length===8&&metadata.functions.length===4,'EXACT_SCHEMA_COUNTS');
const c=current.execution.current;
need(c.active_ga_id===null&&c.pending_budget_sequence===null&&c.sequence===9&&c.charged_seconds===2706&&c.charged_evidence_bytes===590982067,'QUIESCENT_UNREFUNDED_ORIGINAL_BUDGET');
need(current.execution.attempts.length===2&&current.execution.attempts.every(a=>a.phase==='BLOCKED'&&sha(a.receipt_raw)===a.receipt_sha256),'EXACT_TWO_TERMINAL_RECEIPTS');
const before=view(current),after=structuredClone(before);
for(const change of impact.functions){
 const old=before.functions.find(f=>f.name===change.name);need(same(old,change.previous),'EXACT_ORIGINAL_FUNCTION_'+change.name);
 const m=metadata.functions.find(f=>f.name===change.name);need(m&&sha(m.prosrc)===change.new_prosrc_sha256,'ACTUAL_NEW_BODY_'+change.name);
 for(const k of ['acl','owner','security_definer','config'])need(same(old[k],m[k]),'UNCHANGED_FUNCTION_SECURITY_'+k);
 Object.assign(after.functions.find(f=>f.name===change.name),{sha256:sha(m.definition),prosrc_sha256:sha(m.prosrc)});
}
const g=metadata.functions.find(f=>f.name==='effective_execution_binding');
need(g&&g.acl==='{postgres=X/postgres}'&&g.owner==='postgres'&&g.security_definer===true&&same(g.config,['search_path=""','TimeZone=UTC']),'PRIVATE_GETTER_ONLY');
after.functions.push({name:g.name,arguments:'',owner:g.owner,acl:g.acl,config:g.config,security_definer:g.security_definer,sha256:sha(g.definition),prosrc_sha256:sha(g.prosrc)});
after.functions.sort((a,b)=>a.name<b.name?-1:a.name>b.name?1:0);
const quote=x=>"'"+x.replaceAll("'","''")+"'";
function guard(expected,label){return `do $guard$ declare actual jsonb; begin
lock table clued_control.accepted_binding,clued_control.current_head,clued_control.events,clued_control.execution_binding,clued_control.execution_current,clued_control.execution_events,clued_control.gate_attempts,clued_control.control_objects in share row exclusive mode;
if clock_timestamp() >= '2026-09-09T09:28:59Z'::timestamptz then raise exception 'owner_window_expired'; end if;
select to_jsonb(s)-'observed_at'-'transition_definition' into actual from (${snapshotQuery}) s;
if actual is distinct from ${quote(JSON.stringify(expected))}::jsonb then raise exception '${label}'; end if;
end $guard$;\n`;}
const sql="set local clued_control.target_project='uscrdifznmlvczcekqpw';\n"+guard(before,'binding_component_preimage_drift')+patch+'\n'+guard(after,'binding_component_postimage_drift')+snapshotQuery+';\n';
const out={state:'EXACT_PRIVATE_GETTER_THREE_FUNCTION_INSTALL_PREPARED_NOT_EXECUTED',sql,sql_sha256:sha(sql),accepted_component_sha256:sha(patch),metadata_sha256:sha(metadataRaw),expected_full_postimage:after,data_change:false,authority_effect:'NONE'};
fs.writeFileSync('work/binding-component-install-preparation.json',JSON.stringify(out,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({state:out.state,sql_sha256:out.sql_sha256,sql_bytes:Buffer.byteLength(sql),functions:after.functions.filter(f=>metadata.functions.some(m=>m.name===f.name))}));
