import '../kernel-phase2-repo/scripts/phase2-qualification/control-context-verifier-evidence-blob-successor/context.mjs';
process.stderr.write('NORMAL600_CONTEXT_READY\n');
await import('../kernel-phase2-repo/scripts/phase2-qualification/control-context-verifier-evidence-blob-successor/cli.mjs');