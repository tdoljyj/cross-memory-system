import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {compatibilityArtifacts,assembleWithCompatibility,prepareReservation,sha} from './assemble-with-b.mjs';
import {wrap,assemble} from '../assemble-evidence.mjs';
const here=path.dirname(fileURLToPath(import.meta.url)),repo=path.resolve(here,'../../kernel-phase2-repo');
const sources=JSON.parse(fs.readFileSync(path.join(here,'ExactSources.json'),'utf8'));
const real=()=>Object.fromEntries(['compatibility','installation','restoration'].map(name=>{
 const p=sources[name];if(!p)return[name,null];const raw=fs.readFileSync(path.join(repo,p.path),'utf8');return[name,{raw,sha256:sha(raw)}];
}));
test('rejects changed compatibility bytes even when caller recomputes their hash',()=>{
 const x=real();x.compatibility.raw+=' ';x.compatibility.sha256=sha(x.compatibility.raw);
 assert.throws(()=>compatibilityArtifacts(x),/EXACT_ORIGINAL_COMPATIBILITY_BYTES/);
});
test('rejects swapped historical installation and compatibility reports',()=>{
 const x=real();[x.compatibility,x.installation]=[x.installation,x.compatibility];
 assert.throws(()=>compatibilityArtifacts(x),/EXACT_ORIGINAL_COMPATIBILITY_BYTES/);
});
test('rejects forged currentness added to the original historical installation bytes',()=>{
 const x=real(),v=JSON.parse(x.installation.raw);v.current_database_identity=true;
 x.installation.raw=JSON.stringify(v)+'\n';x.installation.sha256=sha(x.installation.raw);
 assert.throws(()=>compatibilityArtifacts(x),/EXACT_ORIGINAL_INSTALLATION_BYTES/);
});
test('does not accept arbitrary fourth attachments or replacement role metadata',()=>{
 const x=real();x.extra={raw:'{}\n',sha256:sha('{}\n')};
 assert.throws(()=>compatibilityArtifacts(x),/EXACT_THREE_COMPATIBILITY_SOURCES/);
});
test('missing restoration original bytes never becomes current applicability',()=>{
 const x=real();x.restoration=null;
 assert.throws(()=>compatibilityArtifacts(x),/ACTUAL_INDEPENDENT_RESTORATION_REPORT_NOT_YET_BOUND|EXACT_ORIGINAL_RESTORATION_BYTES/);
});
test('real exact three reports preserve original bytes and distinct content addresses',()=>{
 if(!sources.restoration){assert.throws(()=>compatibilityArtifacts(real()),/ACTUAL_INDEPENDENT_RESTORATION_REPORT_NOT_YET_BOUND/);return;}
 const x=real(),result=compatibilityArtifacts(x);
 assert.equal(result.length,3);assert.equal(new Set(result.map(x=>x.uri)).size,3);
 for(let i=0;i<3;i++){const n=['compatibility','installation','restoration'][i];assert.equal(result[i].raw,x[n].raw);assert.equal(result[i].sha256,x[n].sha256);}
});
test('synthetic in-memory nineteen-case assembly preserves all original bytes and enforces entire request size',()=>{
 // Deliberately synthetic BLOCKED assessment fixtures: never real case evidence or qualification.
 assert.ok(sources.restoration,'Run this final integration check only after the real report exists');
 const ga=JSON.parse(JSON.parse(fs.readFileSync(path.resolve(here,'../../qualification-live/next-normal600/material.json'),'utf8')).ga_raw);
 ga.gate_authorization_id='ga_'+'0'.repeat(32);
 const raw=x=>JSON.stringify(x)+'\n',gaRaw=raw(ga);
 const suite=JSON.parse(fs.readFileSync(path.join(repo,'scripts/phase2-qualification/control-context-verifier-runtime600/preentry-skill-qualification.json'),'utf8'));
 const observation_input={ga_raw:gaRaw,shared_artifacts:[],source_observations:Object.keys(suite.tests).map(test_id=>{
  const s=raw({kind:'ACTUAL_CLEANUP_NO_BROADER_AUTHORITY_OBSERVATION',ga_id:ga.gate_authorization_id,ga_sha256:sha(gaRaw),test_id,observed_at:ga.issued_at,fixture:'SYNTHETIC_IN_MEMORY_NONQUALIFYING'});
  return {test_id,raw:s,sha256:sha(s)};
 })};
 const wrapped=wrap(observation_input),metadata=JSON.parse(fs.readFileSync(path.join(here,'../GRRMetadataSources.json'),'utf8')).metadata;
 metadata.requested_result='BLOCKED';
 const assessments=wrapped.tests.map(t=>{const s=raw({kind:'INDEPENDENT_TEST_ORACLE_ASSESSMENT',ga_id:wrapped.ga_id,ga_sha256:wrapped.ga_sha256,test_id:t.test_id,test_definition_digest:t.test_definition_digest,expected_outcome_digest:t.expected_outcome_digest,observation_refs:t.observation_refs,result:'BLOCKED',reason:'SYNTHETIC_IN_MEMORY_NONQUALIFYING',independent_reviewer:'/root/project_list_auth_fix',reviewer_ref:metadata.independent_reviewer_ref});return {raw:s,sha256:sha(s)};});
 const input={observation_input,metadata,assessments,b_compatibility_evidence:real()},actual=assembleWithCompatibility(input),extra=compatibilityArtifacts(real());
 const prior=assemble({...input,metadata:{...metadata,input_artifact_digests:[...metadata.input_artifact_digests,...extra.map(x=>x.sha256)]}});
 const before=JSON.parse(prior.index.raw),after=JSON.parse(actual.index.raw);
 assert.equal(actual.decision.raw,prior.decision.raw);assert.deepEqual(after.tests,before.tests);assert.deepEqual(after.artifacts.slice(0,-3),before.artifacts);assert.deepEqual(after.artifacts.slice(-3),extra);
 assert.equal(actual.receipt_evidence_fields.test_results.length,19);assert.equal(actual.receipt_evidence_fields.raw_evidence_refs.length,after.artifacts.length);
 assert.equal(actual.receipt_evidence_fields.evidence_index_ref.sha256,sha(actual.index.raw));
 const prepared=prepareReservation({assembly_input:input,expected_sequence:0,idempotency_key:'SYNTHETIC_IN_MEMORY_ONLY'});
 assert.equal(prepared.request.body.evidence_index_raw,actual.index.raw);assert.equal(prepared.size.within_limit,true);
 assert.equal(assembleWithCompatibility({...input,assessments:assessments.slice(1)}).state,'BLOCKED_MISSING_REAL_INPUT'); // B reports never replace independent case coverage.
 const oversized={...input,assessments:assessments.map(a=>{const v=JSON.parse(a.raw);v.reason='SYNTHETIC_SIZE_ONLY:'+('"'.repeat(3000));const s=raw(v);return{raw:s,sha256:sha(s)};})};
 assert.throws(()=>prepareReservation({assembly_input:oversized,expected_sequence:0,idempotency_key:'SYNTHETIC_SIZE_ONLY'}),/INDEX_EXCEEDS_131072/);
});
