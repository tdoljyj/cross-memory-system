// Ordinary Evidence assembly only: no SQL, signature, host action or case assessment.
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {fileURLToPath,pathToFileURL} from 'node:url';
const here=path.dirname(fileURLToPath(import.meta.url)),base=path.resolve(here,'..');
const need=(v,m)=>{if(!v)throw Error(m);},raw=x=>JSON.stringify(x)+'\n';
export const sha=x=>crypto.createHash('sha256').update(x).digest('hex');
const pins={ 'assemble-evidence.mjs':'664e7b13f0f318538dd1460de628f62a745b5932565cd01ec9b400c65d10c14f', 'transition-size.mjs':'7c9eff9376c0a447b82a5867a1a7ffb1dfe402a354afa23a5e76d647e0df4ba0'};
for(const [p,h] of Object.entries(pins))need(sha(fs.readFileSync(path.join(base,p)))===h,'ORIGINAL_PREPARATION_SOURCE_DRIFT:'+p);
const {assemble}=await import(pathToFileURL(path.join(base,'assemble-evidence.mjs')));
const {measureDecisionRequest}=await import(pathToFileURL(path.join(base,'transition-size.mjs')));
const root='ctr_414bd3c724264a83894b0c55cf2ab878',controller='edf31377656e1a9a473d0095df72231c058266007e4fd4046e0a9b8c2d6a60d9';
const prefix='urn:clued:execution-evidence:'+root+':';
const fixed={compatibility:'e433f421b768c548d992cb490a5b5f266c133006b2aecaa9386899d6d1b9f0d6',installation:'400d614e804b899ea8617b7309933ced517db08f457d55653259f31e0329bfae'};
function restorationPin(){
 const p=JSON.parse(fs.readFileSync(path.join(here,'ExactSources.json'),'utf8'));
 need(p.state==='ACTUAL_RESTORATION_REPORT_RECEIVED_EXACT_BYTES_BOUND'&&/^[0-9a-f]{64}$/.test(p.restoration?.sha256),'ACTUAL_INDEPENDENT_RESTORATION_REPORT_NOT_YET_BOUND');
 return p.restoration;
}
export function compatibilityArtifacts(evidence){
 need(evidence&&Object.keys(evidence).sort().join(',')==='compatibility,installation,restoration','EXACT_THREE_COMPATIBILITY_SOURCES');
 for(const [name,h] of Object.entries(fixed))need(typeof evidence[name]?.raw==='string'&&evidence[name].sha256===h&&sha(evidence[name].raw)===h,'EXACT_ORIGINAL_'+name.toUpperCase()+'_BYTES');
 const restore=restorationPin(),expected={...fixed,restoration:restore.sha256};
 const artifacts=Object.keys(expected).map(name=>{
  const item=evidence[name];need(typeof item?.raw==='string'&&item.sha256===expected[name]&&sha(item.raw)===expected[name]&&Buffer.byteLength(item.raw)<=131072,'EXACT_ORIGINAL_'+name.toUpperCase()+'_BYTES');
  const value=JSON.parse(item.raw);need(value.independent_reviewer==='/root/project_list_auth_fix','ORIGINAL_INDEPENDENT_REVIEW_SOURCE');
  return {uri:prefix+item.sha256,sha256:item.sha256,raw:item.raw};
 });
 const c=JSON.parse(artifacts[0].raw),i=JSON.parse(artifacts[1].raw),r=JSON.parse(artifacts[2].raw);
 need(c.state==='ACCEPTED_EXACT_DEDICATED_INTENT_RESPONSE_DATABASE_COMPATIBILITY_SUCCESSOR'&&c.original_controller_digest===controller&&i.compatibility_acceptance_sha256===fixed.compatibility,'EXACT_ACCEPTED_B_COMPATIBILITY_CHAIN');
 need(r.state===restore.expected_state,'EXACT_RESTORATION_REPORT_STATE');
 // Exact received report bytes bind its full historical/installation applicability.
 // No current SQL claim or permission is derived from a caller boolean or this report.
 return artifacts;
}
export function assembleWithCompatibility(input){
 const additions=compatibilityArtifacts(input?.b_compatibility_evidence);
 const ga=JSON.parse(input?.observation_input?.ga_raw??'null');
 need(ga?.controller_digest===controller&&ga.gate_id==='G-PREENTRY-SKILL-QUALIFICATION'&&ga.purpose==='SKILL_COEXISTENCE_QUALIFICATION','EXACT_ORIGINAL_NORMAL_QUALIFICATION_SCOPE');
 need(Array.isArray(input?.metadata?.input_artifact_digests),'ORIGINAL_INPUT_DIGESTS_REQUIRED');
 const digests=input.metadata.input_artifact_digests;
 need(additions.every(a=>!digests.includes(a.sha256)),'B_EVIDENCE_ALREADY_BOUND_NO_DUPLICATE_APPEND');
 const originalInput={...input,metadata:{...input.metadata,input_artifact_digests:[...digests,...additions.map(a=>a.sha256)]}};
 delete originalInput.b_compatibility_evidence;
 const original=assemble(originalInput);if(original.state.startsWith('BLOCKED'))return original;
 need(original.missing_cases.length===0&&original.receipt_evidence_fields.test_results.length===19&&input.assessments.length===19,'ALL_NINETEEN_ACTUAL_ASSESSMENTS_STILL_REQUIRED');
 const index=JSON.parse(original.index.raw),testsBefore=raw(index.tests),artifactsBefore=raw(index.artifacts);
 index.artifacts.push(...additions);
 need(new Set(index.artifacts.map(a=>a.uri)).size===index.artifacts.length&&index.artifacts.length<=256,'EXACT_UNIQUE_ORIGINAL_INDEX_ARTIFACTS');
 const indexRaw=raw(index);need(Buffer.byteLength(indexRaw)<=131072,'INDEX_EXCEEDS_131072_NO_OMISSION');
 need(raw(index.tests)===testsBefore&&raw(index.artifacts.slice(0,-3))===artifactsBefore,'ORIGINAL_TEST_AND_ARTIFACT_BYTES_CHANGED');
 return {...original,index:{raw:indexRaw,sha256:sha(indexRaw),bytes:Buffer.byteLength(indexRaw)},receipt_evidence_fields:{...original.receipt_evidence_fields,evidence_index_ref:{uri:prefix+sha(indexRaw),sha256:sha(indexRaw)},raw_evidence_refs:index.artifacts.map(({uri,sha256})=>({uri,sha256}))},b_compatibility_evidence_refs:additions.map(({uri,sha256})=>({uri,sha256})),current_database_identity_claimed:false};
}
export function prepareReservation(input){
 const assembly=assembleWithCompatibility(input.assembly_input);
 if(assembly.state.startsWith('BLOCKED'))return assembly;
 const d=JSON.parse(assembly.decision.raw),request={ga_id:d.ga_id,idempotency_key:input.idempotency_key,expected_sequence:input.expected_sequence,operation:'DECISION_RESERVED',body:{decision_raw:assembly.decision.raw,decision_sha256:assembly.decision.sha256,evidence_index_raw:assembly.index.raw,evidence_index_sha256:assembly.index.sha256,result:d.result}};
 const size=measureDecisionRequest(request);
 return {state:size.within_limit?'ORIGINAL_REQUEST_PREPARED_REQUIRES_ACTUAL_CURRENT_SQL_CAS':'BLOCKED_ENTIRE_TRANSITION_EXCEEDS_131072',assembly,request,size,authority_effect:'NONE',sql_called:false};
}
function local(p,exists){const f=path.resolve(p),rel=path.relative(base,f);need(rel&&!rel.startsWith('..')&&!path.isAbsolute(rel),'PREPARATION_DIRECTORY_ONLY');for(let x=exists?f:path.dirname(f);;x=path.dirname(x)){need(!fs.lstatSync(x).isSymbolicLink(),'UNLINKED_LOCAL_DATA_PATH');if(x===base)break;}return f;}
if(process.argv[1]&&path.resolve(process.argv[1])===fileURLToPath(import.meta.url)){
 try{
  const [command,inputFile,outputFile]=process.argv.slice(2);need(['assemble','reservation'].includes(command)&&inputFile&&outputFile&&process.argv.length===5,'USAGE: assemble-with-b.mjs assemble|reservation INPUT.json NEW_OUTPUT.json');
  const f=local(inputFile,true);need(fs.statSync(f).isFile()&&fs.statSync(f).size<=16*1024*1024,'BOUNDED_REGULAR_INPUT');
  const input=JSON.parse(fs.readFileSync(f,'utf8')),output=command==='assemble'?assembleWithCompatibility(input):prepareReservation(input),bytes=JSON.stringify(output,null,2)+'\n';
  fs.writeFileSync(local(outputFile,false),bytes,{flag:'wx'});
  process.stdout.write(JSON.stringify({state:output.state,sha256:sha(bytes),request_bytes:output.size?.postgres_jsonb_text_bytes,authority_effect:'NONE'})+'\n');if(output.state.startsWith('BLOCKED'))process.exitCode=2;
 }catch(e){process.stdout.write(JSON.stringify({state:'BLOCKED_INVALID_OR_MISSING_REAL_INPUT',reason:e.message,authority_effect:'NONE'})+'\n');process.exitCode=2;}
}
