// Reuses the existing disposable PG setup; only new remote-evidence checks follow.
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import fs from 'node:fs/promises';
import net from 'node:net';
import os from 'node:os';
import path from 'node:path';
import {createRequire} from 'node:module';
import {fileURLToPath} from 'node:url';
import test from 'node:test';
import {createBudgetStore as createExecutionStore,projectRef,rootId} from '../kernel-phase2-repo/scripts/phase2-qualification/nonproduction-control-store/runtime-successor/budget-reservation-successor/client.mjs';
import {checkDispatchEvidence} from '../kernel-phase2-repo/scripts/phase2-qualification/control-context-verifier-runtime180/dispatch-evidence.mjs';
import {recordQuery,dispatchQuery} from '../kernel-phase2-repo/scripts/phase2-qualification/control-context-verifier-runtime180/transport.mjs';
const evidence={kind:'LOCAL_SYNTHETIC_SQL_INTERFACE_INTEGRATION_NOT_QUALIFICATION',started_at:new Date().toISOString(),observations:[]};
const keep=(label,value)=>{evidence.observations.push({label,observed_at:new Date().toISOString(),value});};
const require=createRequire(new URL('../kernel-phase2-repo/apps/clued-cloud/package.json',import.meta.url));
const EmbeddedPostgres=require('embedded-postgres').default;
const directory=path.dirname(fileURLToPath(import.meta.url));
const sha=raw=>crypto.createHash('sha256').update(raw).digest('hex');
const h='a'.repeat(64),gen='ctrgen_352785779b64458a889d571360e2d2d5',container='c'.repeat(64);
async function port(){const s=net.createServer();await new Promise(r=>s.listen(0,'127.0.0.1',r));const value=s.address().port;await new Promise(r=>s.close(r));return value;}

test('actual SQL response compatibility; synthetic local PG, no host or cryptographic admission',{timeout:180000},async t=>{
 const dir=await fs.mkdtemp(path.join(directory,'pg-data-'));
 const server=new EmbeddedPostgres({databaseDir:dir,user:'postgres',password:crypto.randomBytes(32).toString('hex'),port:await port(),persistent:false,postgresFlags:['-c','io_method=sync'],onLog(){},onError(m){process.stderr.write(m+'\n');}});
 const clients=[];
 try{
  await server.initialise();await server.start();const admin=server.getPgClient();clients.push(admin);await admin.connect();
  await admin.query('create role anon nologin;create role authenticated nologin;create role service_role nologin bypassrls;create table public.legacy_sentinel(value text);insert into public.legacy_sentinel values(\'unchanged\');');
  const oldSql=await fs.readFile(path.join(directory,'../kernel-phase2-repo/scripts/phase2-qualification/nonproduction-control-store/install.candidate.sql'),'utf8');
  const sql=await fs.readFile(path.join(directory,'../kernel-phase2-repo/scripts/phase2-qualification/nonproduction-control-store/runtime-successor/budget-reservation-successor/install.candidate.sql'),'utf8');
  await assert.rejects(admin.query(sql),/wrong_or_missing_existing_control_domain/);
  await admin.query("set clued_control.target_project='uscrdifznmlvczcekqpw'");await admin.query(oldSql);
  const privileges=(await admin.query("select oid::regprocedure::text name,proacl::text,prosecdef,proconfig from pg_proc where pronamespace='clued_control'::regnamespace order by name")).rows;
  await admin.query(sql);
  const oldNames=privileges.map(x=>x.name);
  assert.deepEqual((await admin.query("select oid::regprocedure::text name,proacl::text,prosecdef,proconfig from pg_proc where pronamespace='clued_control'::regnamespace order by name")).rows.filter(x=>oldNames.includes(x.name)),privileges);
  const connect=async role=>{const c=server.getPgClient();clients.push(c);await c.connect();await c.query('set role '+role);return c;};
  const writer=await connect('service_role'),other=await connect('service_role');
  const store=createExecutionStore({project:projectRef,query:writer.query.bind(writer)}),store2=createExecutionStore({project:projectRef,query:other.query.bind(other)});
  // Synthetic metadata is injected only into this throwaway database by its admin.
  // G1 here tests string binding; it is NOT a proposed applicable pre-entry Gate.
  await admin.query(`insert into clued_control.accepted_binding values($1,$2,'SKILL_COEXISTENCE_QUALIFICATION','ISOLATED_TEST',
   'e4ab25ecb1fa6709435d0318ad431d14343482cbe84e232f638e55c3c4ba1e1f','4d7f93c17cf7d126e771cf8aca6299c868cba0a9',
   clock_timestamp()-interval '1 minute',least(clock_timestamp()+interval '10 minutes','2026-09-09T09:28:59Z'),
   'SYNTHETIC_ISSUER','SYNTHETIC_AUDIENCE','SYNTHETIC_CONFIG',$3,$3,$3,$3,$3)`,[rootId,projectRef,h]);
  await admin.query('insert into clued_control.current_head values($1,1,$2,false)',[rootId,gen]);
  await admin.query("insert into clued_control.execution_binding values($1,$2,$2,$2,$2,'G-PREENTRY-SKILL-QUALIFICATION','SYNTHETIC_DEFINITION_NOT_ACCEPTED',$2,$2,1410,19264968)",[rootId,h]);
  await admin.query("insert into clued_control.execution_current values($1,'runner-initial','credential-initial','session-initial',0,null,null,1410,19264968)",[rootId]);
  const makeGa=key=>{const now=Date.now();return {gate_authorization_id:'ga_'+key,idempotency_key:key,authorization_status:'AUTHORIZED',purpose:'SKILL_COEXISTENCE_QUALIFICATION',environment:'ISOLATED_TEST',
   profile_digest:h,controller_digest:h,scope_digest:h,gate_id:'G-PREENTRY-SKILL-QUALIFICATION',controller_qualification_ref:{sha256:h},control_trust_root_generation:gen,
   runner_generation:'runner-initial',credential_generation:'credential-initial',session_generation:'session-initial',
   issued_at:new Date(now-1000).toISOString(),deadline:new Date(now+60000).toISOString(),expires_at:new Date(now+60000).toISOString()};};


  const sm={object_type:'StatusManifest',schema_version:'1.0',schema_digest:'6ba12ed51b3fc0e457c13e83f47e1ad1aa6cc680d8f28c668f8c65d12742ecc2',
   status_manifest_id:'sm_budget',issuer_purpose:'STATUS',audience:'urn:clued:audience:skill-coexistence-qualification:uscrdifznmlvczcekqpw',
   control_trust_root_generation:gen,generation:1,as_of:new Date(Date.now()-1000).toISOString(),expires_at:new Date(Date.now()+300000).toISOString(),signature_binding:{synthetic_only:true}};
  const smRaw=JSON.stringify(sm)+'\n';await store.appendStatus(smRaw);
  const allocation=key=>({controller_digest:h,credential_generation:'credential-initial',environment:'ISOLATED_TEST',evidence_bytes:134217728,
   expires_at:new Date(Date.now()+300000).toISOString(),idempotency_key:key,not_before:new Date(Date.now()-1000).toISOString(),profile_digest:h,
   purpose:'SKILL_COEXISTENCE_QUALIFICATION',root_generation:gen,runner_generation:'runner-initial',scope_digest:h,seconds:180,session_generation:'session-initial'});
  const gaFor=(key,ref)=>({...makeGa(key),issued_at:new Date(Date.now()-100).toISOString(),
   status_manifest_ref:{uri:'control://status-manifests/sm_budget',sha256:sha(smRaw)},budget_reservation_ref:ref});
  const securitySql="select oid::regprocedure::text name,pg_get_functiondef(oid) definition,prosrc,proacl::text,prosecdef,proconfig from pg_proc where pronamespace='clued_control'::regnamespace order by name";
  const beforeFunctions=(await admin.query(securitySql)).rows;
  const rootRows=async()=> (await admin.query("select jsonb_build_object('binding',(select jsonb_agg(t) from clued_control.accepted_binding t),'head',(select jsonb_agg(t) from clued_control.current_head t),'events',(select jsonb_agg(t) from clued_control.events t)) value")).rows[0].value;
  // Full runtime data snapshot around ONLY the wrapper installation.
  const beforeState=await store.read();
  const candidate=await fs.readFile(path.join(directory,'record-effect-intent-response.candidate.sql'),'utf8');
  await admin.query(candidate);
  const afterFunctions=(await admin.query(securitySql)).rows;
  keep('wrapper_install',{candidate_sha256:sha(candidate),beforeFunctions,afterFunctions,beforeState,afterState:await store.read()});
  assert.deepEqual(await store.read(),beforeState);
  for(let i=0;i<beforeFunctions.length;i++){
   const a=beforeFunctions[i],b=afterFunctions[i];
   if(a.name.startsWith('clued_control.record_effect_intent(')){
    assert.notEqual(a.prosrc,b.prosrc);for(const k of ['name','proacl','prosecdef','proconfig'])assert.deepEqual(a[k],b[k]);
   }else assert.deepEqual(a,b);
  }
  const rawGa=JSON.stringify(gaFor('interface', (await store.reserveBudget(JSON.stringify(allocation('interface_budget'))+'\n')).budget_reservation_ref));
  await store.reserveExactGa(rawGa);
  const gaId='ga_interface',gaHash=sha(rawGa);
  const initial=await store.read();
  let counter=0;
  const transition=async(operation,body)=>{const current=await store.read();const request={ga_id:gaId,idempotency_key:'interface_event_'+(++counter),expected_sequence:current.current.sequence,operation,body};const result=await store.transition(request);keep(operation,{request,result});return result;};
  const outerSource=await fs.readFile(path.join(directory,'../kernel-phase2-repo/scripts/phase2-qualification/control-context-verifier-runtime600/tool-entry.functions.js'),'utf8');
  const originalLine=outerSource.split(/\r?\n/).find(x=>x.includes("throw Error('NO_DISPATCH_ON_OLD_OR_UNKNOWN_INTENT')"));
  assert.ok(originalLine);const outerCheck=new Function('record',originalLine);keep('original_outer_check',{source_sha256:sha(outerSource),exact_line:originalLine});
  const identity=()=>({ga_id:gaId,ga_sha256:gaHash});
  const unchanged=async(fn,pattern)=>{const before=await store.read();let error;try{await fn();assert.fail('must reject');}catch(e){error={message:e.message,code:e.code};assert.match(e.message,pattern);}const after=await store.read();assert.deepEqual(after,before);keep('rejected_without_state_change',{error,before,after});};
  const effect=async(operation)=>{
   const raw=JSON.stringify({...identity(),operation})+'\n';
   const intent={gaId,key:'intent_'+sha(operation),body:{operation,raw,sha256:sha(raw)}};
   const dispatchKey='clued_'+sha(operation+'_dispatch');
   // Actual two connections / two explicitly committed transactions.
   await writer.query('begin');const recorded=(await writer.query(recordQuery(intent))).rows[0].recorded;await writer.query('commit');
   const phase=operation==='CREATE'?'PENDING':'CREATED';
   assert.equal(recorded.phase,'INTENT_RECORDED');assert.equal(recorded.operation,'INTENT_RECORDED');assert.equal(recorded.attempt_phase,phase);
   assert.equal(recorded.current_context.attempts[0].phase,phase);assert.equal((await store2.read()).attempts[0].phase,phase);
   const record={project:projectRef,query:recordQuery(intent),row:{recorded}};outerCheck(record);
   await unchanged(()=>store2.recordIntent({...intent,body:{...intent.body,raw:raw+' '}}),/idempotency_conflict/);
   const duplicate=(await other.query(recordQuery(intent))).rows[0].recorded;
   assert.equal(duplicate.status,'DUPLICATE');assert.throws(()=>outerCheck({...record,row:{recorded:duplicate}}),/NO_DISPATCH/);
   const beforeDispatch=await store.read();
   assert.equal(beforeDispatch.events.filter(e=>e.request.operation===operation+'_SENT').length,0);
   await unchanged(()=>store2.dispatchIntent({gaId,operation,key:dispatchKey,sequence:recorded.sequence,digest:'f'.repeat(64)}),/exact_prior_committed_intent_required/);
   await other.query('begin');const query=dispatchQuery(intent,recorded.sequence,dispatchKey);const dispatched=(await other.query(query)).rows[0].dispatched;await other.query('commit');
   const dispatch={project:projectRef,query,row:{dispatched}};
   const args={record,dispatch,intent,dispatchKey,project:projectRef,operation};
   assert.equal(checkDispatchEvidence(args).state,'DISPATCH_EVIDENCE_MATCHED_NOT_ADMISSION');
   for(const change of [x=>x.record.row.recorded.phase=phase,x=>x.record.row.recorded.status='DUPLICATE',x=>x.dispatch.row.dispatched.prior_committed_intent_readback.request.body.raw+='x',x=>x.dispatch.row.dispatched.phase=phase]){const x=structuredClone(args);change(x);assert.throws(()=>checkDispatchEvidence(x));}
   const final=await store.read();assert.equal(final.current.charged_seconds,initial.current.charged_seconds);assert.equal(final.current.charged_evidence_bytes,initial.current.charged_evidence_bytes);
   keep(operation+'_real_two_transaction_integration',{args,duplicate,original_inner_result:'MATCHED_NOT_ADMISSION',unchanged_budget:true});
  };
  const observed=async operation=>{const observation={Id:container,synthetic_sql_setup_only:true};const raw=JSON.stringify({...identity(),operation,container_id:container,observation});return transition(operation,{container_id:container,raw,sha256:sha(raw),...(operation==='STOPPED'?{observation_sha256:sha(JSON.stringify(observation))}:{})});};
  await t.test('CREATE SQL record/committed dispatch feeds both original frozen consumers',async()=>{
   const badRaw=JSON.stringify({...identity(),ga_id:'ga_wrong',operation:'CREATE'});
   await unchanged(()=>store.recordIntent({gaId,key:'intent_'+sha('wrong_ga'),body:{operation:'CREATE',raw:badRaw,sha256:sha(badRaw)}}),/intent_binding_mismatch/);
   await effect('CREATE');assert.equal((await observed('CREATED')).phase,'CREATED');
  });
  await t.test('START SQL record/committed dispatch feeds both original consumers; true CREATED retained',async()=>{await effect('START');assert.equal((await observed('RUNNING')).phase,'RUNNING');});
  await t.test('remaining adjacent SQL response chain; synthetic observations, not host PASS or signed qualification',async()=>{
   assert.equal((await transition('STOP_SENT',{container_id:container})).phase,'STOP_SENT');
   assert.equal((await observed('STOPPED')).phase,'STOPPED');
   const decisionRaw=JSON.stringify({...identity(),result:'BLOCKED',synthetic_sql_setup_only:true}),indexRaw=JSON.stringify({...identity(),tests:[],synthetic_sql_setup_only:true});
   const body={result:'BLOCKED',decision_raw:decisionRaw,decision_sha256:sha(decisionRaw),evidence_index_raw:indexRaw,evidence_index_sha256:sha(indexRaw)};
   assert.equal((await transition('DECISION_RESERVED',body)).phase,'DECISION_RESERVED');
   await unchanged(()=>transition('SIGNING',{decision_sha256:'f'.repeat(64)}),/signing_reservation_conflict/);
   assert.equal((await transition('SIGNING',{decision_sha256:body.decision_sha256})).phase,'SIGNING');
   const receipt=JSON.stringify({gate_result_receipt_id:'grr_interface_only',gate_authorization_id:gaId,result:'BLOCKED',schema_digest:h,issuer_purpose:'GATE_RESULT',audience:'SYNTHETIC_ONLY',signature:'NOT_A_REAL_SIGNATURE_SQL_STORAGE_TEST_ONLY'});
   const committed=await store.commitExactResult(receipt,body.decision_sha256);assert.equal(committed.status,'COMMITTED');assert.equal(committed.result,'BLOCKED');
   const duplicate=await store2.commitExactResult(receipt,body.decision_sha256);assert.equal(duplicate.status,'DUPLICATE');
   const after=await store.read();assert.equal(after.current.active_ga_id,null);assert.equal(after.current.charged_seconds,initial.current.charged_seconds);assert.equal(after.current.charged_evidence_bytes,initial.current.charged_evidence_bytes);
   keep('SQL_STORAGE_ONLY_FINAL',{receipt,committed,duplicate,after,cryptographic_and_host_verifiers_executed:false});
  });
  assert.deepEqual((await admin.query('select * from public.legacy_sentinel')).rows,[{value:'unchanged'}]);

 }finally{await Promise.all(clients.map(c=>c.end().catch(()=>{})));await server.stop();evidence.ended_at=new Date().toISOString();evidence.cleanup='server.stop completed; no remote connection or Docker';await fs.writeFile(path.join(directory,'PgIntegrationRaw.json'),JSON.stringify(evidence,null,2)+'\n',{flag:'wx'});}
});
