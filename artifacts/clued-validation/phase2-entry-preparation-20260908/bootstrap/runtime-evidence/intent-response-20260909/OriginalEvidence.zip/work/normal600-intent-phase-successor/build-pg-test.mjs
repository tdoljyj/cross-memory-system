import fs from 'node:fs';
const dir=new URL('./',import.meta.url),repo=new URL('../kernel-phase2-repo/',dir);
let source=fs.readFileSync(new URL('scripts/phase2-qualification/nonproduction-control-store/runtime-successor/budget-reservation-successor/budget.test.mjs',repo),'utf8');
source=source.replace("from './client.mjs'","from '../kernel-phase2-repo/scripts/phase2-qualification/nonproduction-control-store/runtime-successor/budget-reservation-successor/client.mjs'")
 .replace("../../../../../apps/clued-cloud/package.json","../kernel-phase2-repo/apps/clued-cloud/package.json")
 .replace("path.join(directory,'../../install.candidate.sql')","path.join(directory,'../kernel-phase2-repo/scripts/phase2-qualification/nonproduction-control-store/install.candidate.sql')")
 .replace("path.join(directory,'install.candidate.sql')","path.join(directory,'../kernel-phase2-repo/scripts/phase2-qualification/nonproduction-control-store/runtime-successor/budget-reservation-successor/install.candidate.sql')")
 .replace("path.join(os.tmpdir(),'clued-execution-store-')","path.join(directory,'pg-data-')");
source=source.replace("test('same-domain runtime SQL candidate; synthetic local PG only'","test('actual SQL response compatibility; synthetic local PG, no host or cryptographic admission'");
source=source.replace(/  await t\.test\('empty install[\s\S]*?  \/\/ Synthetic metadata/, '  // Synthetic metadata');
source=source.slice(0,source.indexOf("  await t.test('budget must"));
const extras=fs.readFileSync(new URL('pg-cases.txt',dir),'utf8');
source=source.replace("const require=createRequire",`import {checkDispatchEvidence} from '../kernel-phase2-repo/scripts/phase2-qualification/control-context-verifier-runtime180/dispatch-evidence.mjs';
import {recordQuery,dispatchQuery} from '../kernel-phase2-repo/scripts/phase2-qualification/control-context-verifier-runtime180/transport.mjs';
const evidence={kind:'LOCAL_SYNTHETIC_SQL_INTERFACE_INTEGRATION_NOT_QUALIFICATION',started_at:new Date().toISOString(),observations:[]};
const keep=(label,value)=>{evidence.observations.push({label,observed_at:new Date().toISOString(),value});};
const require=createRequire`);
source+=extras;
source+=`\n }finally{await Promise.all(clients.map(c=>c.end().catch(()=>{})));await server.stop();evidence.ended_at=new Date().toISOString();evidence.cleanup='server.stop completed; no remote connection or Docker';await fs.writeFile(path.join(directory,'PgIntegrationRaw.json'),JSON.stringify(evidence,null,2)+'\\n',{flag:'wx'});}\n});\n`;
fs.writeFileSync(new URL('pg-integration.test.mjs',dir),source);
