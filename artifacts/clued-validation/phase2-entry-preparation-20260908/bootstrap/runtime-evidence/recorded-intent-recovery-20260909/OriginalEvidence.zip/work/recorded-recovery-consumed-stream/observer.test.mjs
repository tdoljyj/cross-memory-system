import test from 'node:test';import assert from 'node:assert/strict';import {EventEmitter} from 'node:events';import crypto from 'node:crypto';
import {installPrefixObserver} from './prefix-observer.mjs';import {prepareTimestampStream} from '../recovery-timestamp-stream.mjs';
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
test('prefix ACK rejects changed bytes, early line, wrong plan phase; frame rejects changed complete state',()=>{
 for(const [bytes,plan] of [['abd',{phase:1,bytes:3,sha256:sha('abc')}],['a\n',{phase:1,bytes:3,sha256:sha('abc')}],['abc',{phase:2,bytes:3,sha256:sha('abc')}]]){
  const input=new EventEmitter();let ack=0;installPrefixObserver(input,()=>plan,()=>ack++);assert.throws(()=>input.emit('data',Buffer.from(bytes)));assert.equal(ack,0);
 }
 const observation={project:'uscrdifznmlvczcekqpw',query_sha256:'cb5704c053850f1484f39f4396d638f2e603b7df48f6eb7045fea36b8f072654',row:{execution:{sequence:9},observed_at:'2026-09-08T21:00:00Z'}},frame=prepareTimestampStream({operation:'GRR',grr_raw:'{"result":"BLOCKED"}',observation});
 const changed=structuredClone(observation);changed.row.execution.sequence=10;assert.throws(()=>frame.finish(changed));
});
