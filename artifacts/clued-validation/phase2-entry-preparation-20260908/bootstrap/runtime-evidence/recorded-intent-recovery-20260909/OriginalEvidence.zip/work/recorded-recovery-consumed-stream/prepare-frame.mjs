import fs from 'node:fs';import crypto from 'node:crypto';import {prepareTimestampStream} from '../recovery-timestamp-stream.mjs';
const sha=b=>crypto.createHash('sha256').update(b).digest('hex'),[phaseText,challenge]=process.argv.slice(2),phase=Number(phaseText);
if(![1,2].includes(phase)||phaseText!==String(phase)||(phase===1?challenge!==undefined:!/^[a-f0-9]{48}$/.test(challenge??'')))throw Error('FIXED_TWO_PREFIX_PHASES');
const materialRaw=fs.readFileSync(new URL('../qualification-live/next-normal600/recovery-grr-material.json',import.meta.url)),failureRaw=fs.readFileSync(new URL('../qualification-live/next-normal600/recovery-first-verifier-failure.json',import.meta.url));
if(sha(materialRaw)!=='6a3961037e1a13aca6d5461bfdcf3c3ca4c3b2ae241d23c124ee75644f516432'||sha(failureRaw)!=='5980d36fd504a6985b09068c15fd5535df9d096c6a40ec6a175eb0a22c6296e4')throw Error('EXACT_EXISTING_MATERIAL_AND_FAILURE');
const material=JSON.parse(materialRaw),failed=JSON.parse(failureRaw).inner;
if(failed.state!=='UNKNOWN'||failed.reason!=='FRESH_SQL_OBSERVATION_REQUIRED'||failed.commit_sent!==false||(failed.challenge_sent!==undefined&&failed.challenge_sent!==false)||sha(material.grr_raw)!=='989f56a412ccc2ab0218c983dbdb6b0b5c556eb2c2045cf0896fcdb01e6df630')throw Error('NO_RESIGN_OR_BLIND_RETRY');
material.observation={project:failed.initial.project,query_sha256:'cb5704c053850f1484f39f4396d638f2e603b7df48f6eb7045fea36b8f072654',row:failed.initial.row};
const input=phase===1?material:{challenge,observation:material.observation},prefix=prepareTimestampStream(input).prefix;
const parent={...failed};delete parent.initial;
const value={phase,bytes:Buffer.byteLength(prefix),sha256:sha(prefix),ga_id:failed.ga_id,receipt_id:failed.receipt_id,original_failure_sha256:sha(failureRaw),signed_grr_sha256:sha(material.grr_raw),parent_without_initial:parent,parent_initial_metadata:{project:failed.initial.project,query:failed.initial.query,observed_at:failed.initial.row.observed_at}};
for(const [name,raw] of [['frame'+phase+'.prefix.raw',prefix],['frame'+phase+'.json',JSON.stringify(value)+'\n']]){const fd=fs.openSync(new URL(name,import.meta.url),'wx');try{fs.writeFileSync(fd,raw);fs.fsyncSync(fd);}finally{fs.closeSync(fd);}}
process.stdout.write(JSON.stringify(value)+'\n');
