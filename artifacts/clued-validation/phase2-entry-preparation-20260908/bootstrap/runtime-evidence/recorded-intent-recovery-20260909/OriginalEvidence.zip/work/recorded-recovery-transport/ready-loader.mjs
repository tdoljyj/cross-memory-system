import '../kernel-phase2-repo/scripts/phase2-qualification/recorded-intent-nonpass-successor/recovery-context.mjs';
process.stderr.write('RECORDED_RECOVERY_CONTEXT_READY\n');
await import('../kernel-phase2-repo/scripts/phase2-qualification/recorded-intent-nonpass-successor/recovery-cli.mjs');
