import fs from 'node:fs';import {installPrefixObserver} from './prefix-observer.mjs';
import '../kernel-phase2-repo/scripts/phase2-qualification/recorded-intent-nonpass-successor/recovery-context.mjs';
let scheduled=false;
const noticed=name=>{if(name!=='data'||scheduled)return;scheduled=true;setImmediate(()=>{
 process.stdin.removeListener('newListener',noticed);
 installPrefixObserver(process.stdin,phase=>JSON.parse(fs.readFileSync(new URL('frame'+phase+'.json',import.meta.url),'utf8')),ack=>process.stdout.write(JSON.stringify(ack)+'\n'));
 process.stderr.write('RECORDED_PREFIX_OBSERVER_READY\n');
});};
process.stdin.on('newListener',noticed);
await import('../kernel-phase2-repo/scripts/phase2-qualification/recorded-intent-nonpass-successor/recovery-cli.mjs');
