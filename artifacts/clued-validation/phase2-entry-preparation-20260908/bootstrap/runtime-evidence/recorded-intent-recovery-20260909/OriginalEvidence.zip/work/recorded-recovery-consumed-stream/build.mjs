import fs from 'node:fs';import crypto from 'node:crypto';
const dir='work/recorded-recovery-consumed-stream',sha=x=>crypto.createHash('sha256').update(x).digest('hex');
const old=fs.readFileSync('work/kernel-phase2-repo/scripts/phase2-qualification/recorded-intent-nonpass-successor/tool-entry.functions.js','utf8');if(sha(old)!=='44a243074c8fcc137b72277014a3919b53660989e6bbeda365604a42ba868153')throw Error('EXACT_ORIGINAL_SHELL');
const pure=fs.readFileSync('work/recovery-timestamp-stream.mjs','utf8');if(sha(pure)!=='113e503a46ffed9877139c94e02654216f2782d18fb3de66bce3271380c31a5e')throw Error('EXACT_ACCEPTED_TIMESTAMP_FRAMING');
const signed=JSON.parse(fs.readFileSync('work/qualification-live/next-normal600/recovery-grr-material.json','utf8')).grr_raw;if(sha(signed)!=='989f56a412ccc2ab0218c983dbdb6b0b5c556eb2c2045cf0896fcdb01e6df630')throw Error('EXACT_ALREADY_SIGNED_989F');
let inner=pure.replaceAll('export function ','function ')+'\n'+old;
inner=inner.replace("const requested=JSON.parse(material.grr_raw);",()=>`if(material.grr_raw!==${JSON.stringify(signed)})throw Error('EXACT_EXISTING_SIGNED_989F_ONLY');
const requested=JSON.parse(material.grr_raw);`);
inner=inner.replace("const attemptKey='clued_recovery_once_'+requested.gate_result_receipt_id;",`const failed=load('clued_recovery_once_'+requested.gate_result_receipt_id);
if(failed?.state!=='UNKNOWN'||failed.reason!=='FRESH_SQL_OBSERVATION_REQUIRED'||failed.commit_sent!==false||(failed.challenge_sent!==undefined&&failed.challenge_sent!==false)||failed.ga_id!==requested.gate_authorization_id||failed.receipt_id!==requested.gate_result_receipt_id||failed.session!==44645)throw Error('EXACT_FAILED_PRE_CHALLENGE_ATTEMPT_REQUIRED');
const baseline={project,query_sha256,row:JSON.parse(JSON.stringify(failed.initial.row))};
const active=baseline.row.execution.attempts.filter(a=>a.ga_id===requested.gate_authorization_id);
if(baseline.row.execution.current.sequence!==9||active.length!==1||active[0].phase!=='SIGNING'||active[0].receipt_raw!==null)throw Error('EXACT_UNCHANGED_SEQUENCE9_SIGNING_BASELINE');
material.observation=baseline;
const attemptKey='clued_recovery_consumed_prefix_once_'+requested.gate_result_receipt_id;`);
inner=inner.replace("attempt={state:'PROCESS_LAUNCH_RESERVED',",`attempt={parent_attempt_key:'clued_recovery_once_'+requested.gate_result_receipt_id,parent_failure_source:{path:'work/qualification-live/next-normal600/recovery-first-verifier-failure.json',sha256:'5980d36fd504a6985b09068c15fd5535df9d096c6a40ec6a175eb0a22c6296e4'},parent_failure:JSON.parse(JSON.stringify(failed)),signed_grr_raw:material.grr_raw,signed_grr_sha256:'989f56a412ccc2ab0218c983dbdb6b0b5c556eb2c2045cf0896fcdb01e6df630',state:'PROCESS_LAUNCH_RESERVED',`);
const before="  // All process/source startup finishes BEFORE the first actual SQL freshness clock.\n  const initial=await actualSql(query);material.observation={project,query_sha256,row:initial.row};attempt.initial=initial;store(attemptKey,attempt);\n  output=await tools.write_stdin({session_id:attempt.session,chars:JSON.stringify(material)+'\\n',yield_time_ms:1000,max_output_tokens:40000});messages=terminalMessages(output.output);";
const after="  const stream=prepareTimestampStream(material);await tools.consume_prefix({phase:1,prefix:stream.prefix});\n  const initial=await actualSql(query),observation={project,query_sha256,row:initial.row},complete=stream.finish(observation);attempt.initial=initial;attempt.complete_material_raw=complete.complete_raw;attempt.suffix_raw=complete.suffix;store(attemptKey,attempt);material.observation=observation;\n  output=await tools.write_stdin({session_id:attempt.session,chars:complete.suffix,yield_time_ms:1000,max_output_tokens:40000});messages=terminalMessages(output.output);";
const normalized=inner.replaceAll('\r\n','\n');inner=normalized;if(!inner.includes(before))throw Error('ORIGINAL_INITIAL_BLOCK');inner=inner.replace(before,()=>after);
const second="  const fresh=await actualSql(query);attempt.fresh=fresh;store(attemptKey,attempt);\n  output=await tools.write_stdin({session_id:attempt.session,chars:JSON.stringify({challenge:freshNeeded.challenge,observation:{project,query_sha256,row:fresh.row}})+'\\n',yield_time_ms:1000,max_output_tokens:40000});messages=terminalMessages(output.output);";
if(!inner.includes(second))throw Error('ORIGINAL_SECOND_BLOCK');inner=inner.replace(second,()=>"  const stream=prepareTimestampStream({challenge:freshNeeded.challenge,observation:baseline});await tools.consume_prefix({phase:2,prefix:stream.prefix,challenge:freshNeeded.challenge});\n  const fresh=await actualSql(query),complete=stream.finish({project,query_sha256,row:fresh.row});attempt.fresh=fresh;attempt.complete_challenge_raw=complete.complete_raw;attempt.second_suffix_raw=complete.suffix;store(attemptKey,attempt);\n  output=await tools.write_stdin({session_id:attempt.session,chars:complete.suffix,yield_time_ms:1000,max_output_tokens:40000});messages=terminalMessages(output.output);");
fs.writeFileSync(dir+'/inner.functions.js',inner);
for(const name of ['launcher.mjs','read-output.mjs']){let s=fs.readFileSync('work/recorded-recovery-transport/'+name,'utf8');s=s.replaceAll('.recorded-recovery.stdout.raw','.consumed-prefix.stdout.raw');fs.writeFileSync(dir+'/'+name,s);}
let build=fs.readFileSync('work/recorded-recovery-transport/build.mjs','utf8');
build=build.replaceAll('work/recorded-recovery-transport',dir).replaceAll('/recorded-recovery-transport/','/recorded-recovery-consumed-stream/')
 .replace("names=['ready-loader.mjs','launcher.mjs','read-output.mjs']","names=['ready-loader.mjs','launcher.mjs','read-output.mjs','prefix-observer.mjs','prepare-frame.mjs','../recovery-timestamp-stream.mjs']")
 .replace('work/kernel-phase2-repo/scripts/phase2-qualification/recorded-intent-nonpass-successor/tool-entry.functions.js',dir+'/inner.functions.js')
 .replaceAll('44a243074c8fcc137b72277014a3919b53660989e6bbeda365604a42ba868153',sha(inner))
 .replaceAll('clued_recorded_recovery_transport_','clued_consumed_prefix_transport_').replaceAll('RECORDED_RECOVERY_CONTEXT_READY','RECORDED_PREFIX_OBSERVER_READY');
const consume=` consume_prefix:async value=>{
  const {phase,prefix,challenge}=value;if(![1,2].includes(phase)||phase!==(attempt.prefix_phase??0)+1||typeof prefix!=='string'||prefix.includes('\\n')||prefix.includes('\\r')||!attempt.context_ready||(phase===2&&!/^[a-f0-9]{48}$/.test(challenge??'')))throw Error('FIXED_ORDERED_PREFIX_ONLY');
  const command=checks+"& 'C:/Program Files/nodejs/node.exe' 'C:/Users/Windows/Documents/Codex/2026-09-08/ia/work/recorded-recovery-consumed-stream/prepare-frame.mjs' '"+phase+"'"+(phase===2?" '"+challenge+"'":"");
  const prep=await tools.exec_command({cmd:command,workdir:cwd,sandbox_permissions:'require_escalated',justification:'Prepare fixed exact existing signed recovery JSON prefix bytes before a new SQL clock; no authority or effect.',max_output_tokens:2000});if(prep.exit_code!==0)throw Error('EXACT_PREFIX_PLAN_PREPARATION');const plan=JSON.parse(prep.output);
  const parent=load('clued_recovery_once_'+plan.receipt_id),parentRest=JSON.parse(JSON.stringify(parent));delete parentRest.initial;
  if(JSON.stringify(parentRest)!==JSON.stringify(plan.parent_without_initial)||parent.initial.project!==plan.parent_initial_metadata.project||parent.initial.query!==plan.parent_initial_metadata.query||parent.initial.row.observed_at!==plan.parent_initial_metadata.observed_at)throw Error('EXACT_FAILED_PARENT_SOURCE_MISMATCH');
  attempt.records.push({kind:'PREFIX_PLAN',plan,prefix_raw:prefix});attempt.prefix_phase=phase;store(key,attempt);
  const started=Date.now();let result=await tools.write_stdin({session_id:attempt.session,chars:prefix,yield_time_ms:1000,max_output_tokens:2000});
  for(;;){const observed=await capture(result),messages=observed.output.trim()?observed.output.trim().split(/\\r?\\n/).map(x=>JSON.parse(x)):[];
   if(messages.length){if(messages.length!==1)throw Error('ONE_EXACT_PREFIX_ACK');const ack=messages[0];if(ack.state!=='ACTUAL_PREFIX_CONSUMED'||ack.phase!==phase||ack.bytes!==plan.bytes||ack.sha256!==plan.sha256)throw Error('ACTUAL_PREFIX_ACK_MISMATCH');attempt.records.push({kind:'PREFIX_CONSUMPTION_CONFIRMED_BEFORE_FRESH',ack,elapsed_ms:Date.now()-started});store(key,attempt);return;}
   if(result.exit_code!==undefined||Date.now()-started>90000)throw Error('PREFIX_NOT_CONSUMED_NO_FRESH_OR_SUFFIX');result=await tools.write_stdin({session_id:attempt.session,chars:'',yield_time_ms:1000,max_output_tokens:2000});
  }
 },
`;
build=build.replace(' exec_command:async args=>{',consume.replaceAll('\\','\\\\')+' exec_command:async args=>{');
fs.writeFileSync(dir+'/build-outer.mjs',build);
console.log(JSON.stringify({inner_sha256:sha(inner),pure_sha256:sha(pure)}));
