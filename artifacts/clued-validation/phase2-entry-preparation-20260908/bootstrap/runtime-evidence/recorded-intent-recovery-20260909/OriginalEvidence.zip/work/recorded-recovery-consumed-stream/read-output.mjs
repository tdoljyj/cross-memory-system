import fs from 'node:fs';import path from 'node:path';import {fileURLToPath} from 'node:url';import crypto from 'node:crypto';
const dir=path.dirname(fileURLToPath(import.meta.url)),[ga,op,offsetText]=process.argv.slice(2),offset=Number(offsetText);
if(process.argv.length!==5||ga!=="ga_a7a420f7de4a4037b9dcb5cd7dae796e"||op!=='GRR'||!/^(0|[1-9][0-9]*)$/.test(offsetText)||!Number.isSafeInteger(offset))throw Error('FIXED_CAPTURE_READ_ONLY_INPUT');
const file=path.resolve(dir,'../qualification-live',ga+'.'+op+'.consumed-prefix.stdout.raw'),b=fs.readFileSync(file);
if(b.length>2*1024*1024||offset>b.length)throw Error('BOUNDED_ORIGINAL_STDOUT');
const end=b.lastIndexOf(10)+1;if(end<offset)throw Error('NO_CAPTURE_TRUNCATION');
const complete=b.subarray(offset,end),text=new TextDecoder('utf-8',{fatal:true}).decode(complete);
process.stdout.write(JSON.stringify({output:text,next_offset:end,observed_size:b.length,complete_bytes:complete.length,sha256:crypto.createHash('sha256').update(complete).digest('hex'),path:file}));