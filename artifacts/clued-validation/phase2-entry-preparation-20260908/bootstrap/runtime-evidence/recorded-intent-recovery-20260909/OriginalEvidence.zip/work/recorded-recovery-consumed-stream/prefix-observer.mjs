import crypto from 'node:crypto';
// Observer only: never pause/resume, consume, transform, or replace stdin data.
export function installPrefixObserver(input, readPlan, emitAck){
 let phase=1,count=0,hasher=null,plan=null,waitingSuffix=false,suffix=Buffer.alloc(0),pending=false,optionalLF=false;
 const observe=chunk=>{
  let bytes=Buffer.isBuffer(chunk)?chunk:Buffer.from(chunk);
  if(optionalLF){optionalLF=false;if(bytes[0]===10)bytes=bytes.subarray(1);if(bytes.length===0)return;}
  if(phase>2)throw Error('ONLY_TWO_ORIGINAL_INPUTS');
  if(waitingSuffix){
   suffix=Buffer.concat([suffix,bytes]);if(suffix.length>80)throw Error('ONLY_SMALL_REAL_TIMESTAMP_SUFFIX');
   if(suffix.includes(10)||suffix.includes(13)){if(!/^"[^"\r\n]+"\}\}\}(?:\r\n|\r|\n)$/.test(suffix.toString('utf8')))throw Error('EXACT_TIMESTAMP_SUFFIX_FRAME');optionalLF=suffix.at(-1)===13;phase++;count=0;hasher=null;plan=null;waitingSuffix=false;suffix=Buffer.alloc(0);}
   return;
  }
  if(!plan){plan=readPlan(phase);if(plan.phase!==phase||!Number.isSafeInteger(plan.bytes)||plan.bytes<1||plan.bytes>2*1024*1024||!/^[a-f0-9]{64}$/.test(plan.sha256))throw Error('EXACT_LOCAL_PREFIX_PLAN');hasher=crypto.createHash('sha256');}
  if(pending||bytes.includes(10)||bytes.includes(13)||count+bytes.length>plan.bytes)throw Error('NO_EARLY_LINE_OR_PREFIX_OVERFLOW');
  count+=bytes.length;hasher.update(bytes);
  if(count===plan.bytes){
   const digest=hasher.digest('hex');if(digest!==plan.sha256)throw Error('ACTUAL_PREFIX_BYTES_CHANGED');pending=true;
   // Runs after the original readline data listener has handled this event.
   setImmediate(()=>{waitingSuffix=true;pending=false;emitAck({state:'ACTUAL_PREFIX_CONSUMED',phase,bytes:count,sha256:digest,observed_at:new Date().toISOString(),authority_effect:'NONE'});});
  }
 };
 // Caller installs this only after the original readline data listener exists.
 input.on('data',observe);
 return ()=>input.removeListener('data',observe);
}
