import test from 'node:test';import assert from 'node:assert/strict';import crypto from 'node:crypto';import {EventEmitter} from 'node:events';import {installPrefixObserver} from './prefix-observer.mjs';
test('second split CRLF consumes only its optional LF then rejects all third input',async()=>{
 const input=new EventEmitter(),acks=[];installPrefixObserver(input,phase=>({phase,bytes:1,sha256:crypto.createHash('sha256').update('a').digest('hex')}),ack=>acks.push(ack));
 for(let phase=1;phase<=2;phase++){input.emit('data',Buffer.from('a'));await new Promise(setImmediate);assert.equal(acks.length,phase);input.emit('data',Buffer.from('"2026-09-08T21:40:00.000Z"}}}\r'));assert.doesNotThrow(()=>input.emit('data',Buffer.from('\n')));}
 assert.throws(()=>input.emit('data',Buffer.from('a')),/ONLY_TWO_ORIGINAL_INPUTS/);
});
