import fs from 'node:fs';import path from 'node:path';import {fileURLToPath} from 'node:url';import {spawn} from 'node:child_process';
const dir=path.dirname(fileURLToPath(import.meta.url)),work=path.resolve(dir,'..'),[ga,op]=process.argv.slice(2);
if(process.argv.length!==4||ga!=="ga_a7a420f7de4a4037b9dcb5cd7dae796e"||op!=='GRR')throw Error('FIXED_GA_OPERATION_ONLY');
if(process.execPath.replaceAll('\\','/').toLowerCase()!=='c:/program files/nodejs/node.exe')throw Error('FIXED_NODE');
const target=path.join(work,'qualification-live',ga+'.'+op+'.recorded-recovery.stdout.raw');
const fd=fs.openSync(target,'wx');
const child=spawn(process.execPath,[path.join(dir,'ready-loader.mjs')],{cwd:path.join(work,'kernel-phase2-repo'),stdio:['inherit',fd,'inherit'],env:{...process.env,NODE_OPTIONS:'',NODE_PATH:''},windowsHide:true});
child.once('error',()=>{fs.closeSync(fd);process.stderr.write('RECORDED_RECOVERY_LAUNCH_UNKNOWN\n');process.exitCode=1;});
child.once('exit',(code,signal)=>{fs.fsyncSync(fd);fs.closeSync(fd);process.exitCode=code===0&&signal===null?0:1;});