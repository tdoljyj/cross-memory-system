import fs from 'node:fs';import crypto from 'node:crypto';const sha=b=>crypto.createHash('sha256').update(b).digest('hex'),names=['ready-loader.mjs','launcher.mjs','read-output.mjs'];
const source=fs.readFileSync("work/kernel-phase2-repo/scripts/phase2-qualification/recorded-intent-nonpass-successor/tool-entry.functions.js",'utf8');if(sha(source)!=='44a243074c8fcc137b72277014a3919b53660989e6bbeda365604a42ba868153')throw Error('EXACT_ACCEPTED_FRESH_INPUT');
const refs=names.map(name=>({name,sha256:sha(fs.readFileSync('work/recorded-recovery-transport/'+name))}));
const checks=refs.map(x=>`if((Get-FileHash 'C:/Users/Windows/Documents/Codex/2026-09-08/ia/work/recorded-recovery-transport/${x.name}').Hash.ToLowerInvariant() -ne '${x.sha256}'){throw 'TRANSPORT_SOURCE_DRIFT'}; `).join('');
const original=fs.readFileSync('work/kernel-phase2-repo/scripts/phase2-qualification/control-context-verifier-runtime600/tool-entry.functions.js','utf8');
const parser=original.slice(original.indexOf('function parseSqlResult'),original.indexOf('function recordQuery'));
const code=parser+`// External byte transport only. Exact recorded-Intent recovery shell and 11+201 source preflight remain unchanged.
const material=load('clued_exact_recovery_material');if(!material)throw Error('EXACT_ORIGINAL_MATERIAL_REQUIRED');
const ga=JSON.parse(material.ga_raw).gate_authorization_id,op=material.operation;
if(JSON.parse(material.grr_raw).gate_authorization_id!==ga)throw Error('EXACT_SAME_RECOVERY_GA');
if(ga!=="ga_a7a420f7de4a4037b9dcb5cd7dae796e"||op!=='GRR')throw Error('FIXED_GA_OPERATION');
const key='clued_recorded_recovery_transport_'+ga+'_'+op;let attempt=load(key);
if(attempt?.state==='UNKNOWN')throw Error('NO_UNKNOWN_TRANSPORT_RETRY');
if(!attempt){attempt={state:'PREPARING',ga,op,offset:0,source_refs:${JSON.stringify(refs)},records:[]};store(key,attempt);}
const checks=${JSON.stringify(checks)},cwd='C:/Users/Windows/Documents/Codex/2026-09-08/ia/work/kernel-phase2-repo';
async function capture(result){
 attempt.records.push({kind:'ACTUAL_PTY_TOOL_RESULT',result});store(key,attempt);
 if(!attempt.context_ready)return result;
 const read=await tools.exec_command({cmd:checks+"& 'C:/Program Files/nodejs/node.exe' 'C:/Users/Windows/Documents/Codex/2026-09-08/ia/work/recorded-recovery-transport/read-output.mjs' '"+ga+"' '"+op+"' '"+attempt.offset+"'",workdir:cwd,sandbox_permissions:'require_escalated',justification:'Read exact fixed original verifier stdout bytes without terminal rendering; no SQL or effect dispatch.',max_output_tokens:200000});
 if(read.exit_code!==0)throw Error('EXACT_ORIGINAL_STDOUT_READ');
 const observed=JSON.parse(read.output);if(!Number.isSafeInteger(observed.next_offset)||observed.next_offset<attempt.offset||typeof observed.output!=='string')throw Error('EXACT_MONOTONIC_STDOUT_READ');
 attempt.records.push({kind:'ACTUAL_STDOUT_BYTES',...observed});attempt.offset=observed.next_offset;store(key,attempt);
 return {...result,output:observed.output};
}
const ports={
 mcp__codex_apps__supabase_execute_sql:async args=>{
  if(args.project_id!=='uscrdifznmlvczcekqpw')throw Error('FIXED_ORIGINAL_PROJECT');
  if(args.query.startsWith('select clued_control.commit_gate_result(')){
   const read=attempt.last_actual_current_row,now=Date.now(),age=now-Date.parse(read?.observed_at);
   if(op!=='GRR'||!Number.isFinite(age)||age< -1000||age>15000)throw Error('ORIGINAL_GRR_CAS_FRESHNESS_EXPIRED_NO_COMMIT');
   attempt.records.push({kind:'ACTUAL_CAS_PREFLIGHT_CLOCK',observed_at:read.observed_at,checked_at:new Date(now).toISOString(),age_ms:age});store(key,attempt);
  }
  const result=await tools.mcp__codex_apps__supabase_execute_sql(args);
  if(args.query==='select clock_timestamp() as observed_at, clued_control.read_execution() as execution'){attempt.last_actual_current_row=parseSqlResult(result);store(key,attempt);}
  return result;
 },
 exec_command:async args=>{
  const tail="& 'C:/Program Files/nodejs/node.exe' scripts/phase2-qualification/recorded-intent-nonpass-successor/recovery-cli.mjs";
  if(attempt.session||!args.cmd.endsWith(tail)||args.workdir!==cwd)throw Error('FIXED_ORIGINAL_NODE_LAUNCH_ONLY');
  const replacement=checks+"& 'C:/Program Files/nodejs/node.exe' 'C:/Users/Windows/Documents/Codex/2026-09-08/ia/work/recorded-recovery-transport/launcher.mjs' '"+ga+"' '"+op+"'";
  const start=Date.now();let result=await tools.exec_command({...args,cmd:args.cmd.slice(0,-tail.length)+replacement,max_output_tokens:2000});
  attempt.records.push({kind:'ACTUAL_LAUNCH_TOOL_RESULT',result});if(!result.session_id)throw Error('LIVE_TRANSPORT_PROCESS_REQUIRED');attempt.session=result.session_id;store(key,attempt);
  while(!result.output.includes('RECORDED_RECOVERY_CONTEXT_READY')){if(result.exit_code!==undefined||Date.now()-start>60000)throw Error('CONTEXT_NOT_READY_NO_FRESH_INPUT');result=await tools.write_stdin({session_id:attempt.session,chars:'',yield_time_ms:1000,max_output_tokens:2000});attempt.records.push({kind:'ACTUAL_READINESS_TOOL_RESULT',result});store(key,attempt);}
  attempt.context_ready=true;attempt.ready_at=new Date().toISOString();store(key,attempt);return capture({...result,session_id:attempt.session});
 },
 write_stdin:async args=>{
  if(args.session_id!==attempt.session||!attempt.context_ready)throw Error('EXACT_READY_PROCESS_REQUIRED');
  const start=Date.now(),input=args.chars??'',result=await tools.write_stdin(args);
  attempt.records.push({kind:'ACTUAL_DIRECT_STDIN_TRANSFER',started_at:new Date(start).toISOString(),ended_at:new Date().toISOString(),characters:input.length,raw:input,tool_wall_seconds:result.wall_time_seconds});store(key,attempt);
  return capture(result);
 }
};
try{const AsyncFunction=Object.getPrototypeOf(async function(){}).constructor;await new AsyncFunction('tools','load','store','text',${JSON.stringify(source)})(ports,load,store,text);attempt.state='ORIGINAL_ENTRY_RETURNED';store(key,attempt);}catch(e){attempt.state='UNKNOWN';attempt.reason=String(e.message);store(key,attempt);throw e;}
`;
fs.writeFileSync('work/recorded-recovery-transport/tool-entry.functions.js',code);console.log(JSON.stringify({wrapper_sha256:sha(code),sources:refs}));