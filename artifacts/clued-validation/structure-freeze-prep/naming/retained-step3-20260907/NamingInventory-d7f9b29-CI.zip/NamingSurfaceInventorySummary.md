# Clued Naming Surface Inventory — Structure Freeze Preparation

- Schema: `clued.naming-surface-inventory-summary/v1`
- Generated: `2026-09-07T07:28:16.652306Z`
- Repository: `tdoljyj/cross-memory-system`
- Branch: `HEAD`
- Commit: `d7f9b29c7450cb45d1bf07454847b9ed3a3955c1`
- Tree: `c3c98ea9283cbc48dad624f71450faf86c072865`
- Status: `INVENTORY_CANDIDATE_NOT_CLOSEOUT`
- Authority effect: `NONE`

## Coverage

| Surface | Status | Notes |
|---|---|---|
| `repository_tracked_paths` | `SCANNED` | All git-index entries at the exact source commit. |
| `repository_selected_text_content` | `SCANNED` | UTF-8 content scan of selected text/machine surfaces; skipped entries are enumerated. |
| `github_branches_tags_releases_workflows_artifacts` | `SCANNED` | GitHub REST pagination completed. |
| `chatgpt_library_metadata` | `PENDING_EXTERNAL_SNAPSHOT` | Must be supplied as a detached metadata-only inventory; no private payload read is implied. |
| `supabase_identifiers` | `PENDING_EXTERNAL_SNAPSHOT` | Project/schema/table/function/storage/edge-function/auth surface inventory remains separate. |
| `cloudflare_and_other_deployment_identifiers` | `PENDING_EXTERNAL_SNAPSHOT` | Worker/domain/route/deployment/binding identifiers require connector-backed snapshot or formal N/A/retirement proof. |

## Repository inventory

- Tracked entries: **3907**
- Files: **3907**
- Gitlinks: **0**
- Structured identity fields: **58719**
- Indexed identifier tokens: **8689**
- Bare stage references on machine surfaces: **128**
- Case-fold collision sets: **0**
- Unicode NFC collision sets: **0**
- Identical-byte multi-path sets: **724**

## GitHub inventory

- Branches: **3**
- Tags: **11**
- Releases: **5**
- Release assets: **7**
- Workflows: **13**
- Actions artifacts: **33**

## Inventory observations

These are undispositioned inventory observations. They are not automatic architecture findings, acceptance decisions, or migration authorizations.

| ID | Category | Impact | Title |
|---|---|---|---|
| `NSI-OBS-003` | `stage_namespace` | `CROSS_DOMAIN_STAGE_BINDING_RISK` | Bare M*/Slice stage references exist on machine surfaces |
| `NSI-OBS-005` | `lifecycle_token` | `FILENAME_MAY_BE_MISREAD_AS_CURRENT_OR_FINAL_AUTHORITY` | Tracked paths contain vague lifecycle tokens |
| `NSI-OBS-007` | `transport_name` | `TRANSPORT_NAME_DRIFT_REQUIRES_EXACT_BINDING` | Release assets contain transformed or ambiguous transport names |
| `NSI-OBS-008` | `enforcement` | `NAMING_CHECK_NOT_YET_UNBYPASSABLE` | GitHub branches are not marked protected |
| `NSI-OBS-009` | `representation_copy` | `LOGICAL_OBJECT_REPRESENTATION_COPY_CLASSIFICATION_REQUIRED` | Identical bytes exist at multiple tracked paths |

## Boundaries

- This output does not rename or migrate any file.
- It does not create a Registry Root Catalog.
- It does not issue Architecture Acceptance or Structure Freeze.
- It does not enable a required check on `main`.
- External surfaces marked pending remain open within this inventory work item.
