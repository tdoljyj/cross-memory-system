"""Local, evidence-bound review of an already captured development scan."""
import ast
import collections
import hashlib
import json
from pathlib import Path
import re

OUT = Path(__file__).resolve().parent
REPO = OUT.parent / 'phase2-governance-check'
data = json.loads((OUT / 'TypedSurfaceInventory.development.json').read_text(encoding='utf-8'))
summary = json.loads((OUT / 'DevelopmentSummary.json').read_text(encoding='utf-8'))
manifest = {row['path']: row for row in json.loads((OUT / 'ScannedSourceManifest.development.json').read_text(encoding='utf-8'))}
cache = {}
def source(path):
    if path not in cache:
        raw = (REPO / path).read_bytes()
        digest = hashlib.sha256(raw).hexdigest()
        assert digest == manifest[path]['content_sha256'], f'Source changed after scan: {path}'
        cache[path] = (raw.decode('utf-8'), digest)
    return cache[path][0]
def ref(path, symbol=None, line=None):
    text = source(path)
    if line is None:
        line = next(i for i, value in enumerate(text.splitlines(), 1) if symbol in value)
    return {'path': path, 'line': line, 'source_sha256': cache[path][1], 'symbol': symbol}
def py_constant(path, name):
    for node in ast.parse(source(path)).body:
        if isinstance(node, ast.Assign) and any(isinstance(t, ast.Name) and t.id == name for t in node.targets):
            return ast.literal_eval(node.value), ref(path, line=node.lineno, symbol=name)
    raise AssertionError((path, name))

RPC_MAP_SOURCES = {
    'projectRpcByTool': 'apps/clued-cloud/worker/projects.ts',
    'recordRpcByTool': 'apps/clued-cloud/worker/records.ts',
    'p5RpcByTool': 'apps/clued-cloud/worker/p5.ts',
    'rpcByTool': 'apps/clued-cloud/worker/continuity.ts',
}
JS_STRING = r'''(?:"(?:\\.|[^"\\])*"|'(?:\\.|[^'\\])*')'''
def rpc_value_evidence(path, offset, value, basis, symbol):
    text = source(path)
    assert re.fullmatch(r'clued_[a-z0-9_]+', value), (path, value)
    return {'current_name': value, 'source_kind': basis, 'symbol': symbol,
            **ref(path, line=text.count('\n', 0, offset)+1),
            'column': offset-text.rfind('\n', 0, offset),
            'literal_sha256': hashlib.sha256(value.encode()).hexdigest()}
def rpc_map_values(symbol, stack=()):
    assert symbol in RPC_MAP_SOURCES and symbol not in stack, ('Unknown/cyclic RPC map', symbol)
    path = RPC_MAP_SOURCES[symbol]; text = source(path)
    match = re.search(r'\bconst\s+'+symbol+r'\s*=\s*\{(?P<body>[^}]+)\}', text)
    assert match, (path, symbol)
    body = match['body']; records = []
    pattern = r'(?P<spread>\.\.\.(?P<symbol>[A-Za-z_$][\w$]*))|(?P<entry>[A-Za-z_$][\w$]*\s*:\s*(?P<value>'+JS_STRING+'))'
    matches = list(re.finditer(pattern, body))
    assert not re.sub(pattern, '', body).strip(' ,\r\n\t'), ('Unparsed RPC map entry', symbol)
    for entry in matches:
        if entry['spread']:
            records.extend(rpc_map_values(entry['symbol'], (*stack, symbol)))
        else:
            value = ast.literal_eval(entry['value'])
            records.append(rpc_value_evidence(path, match.start('body')+entry.start('value'), value, 'literal_map_value', symbol))
    return records
def rpc_helper_literals(symbol):
    path = RPC_MAP_SOURCES['rpcByTool']; text = source(path); records = []
    for match in re.finditer(r'\b'+symbol+r'\(\s*env\s*,\s*(?P<value>'+JS_STRING+')', text):
        records.append(rpc_value_evidence(path, match.start('value'), ast.literal_eval(match['value']), 'literal_helper_argument', symbol))
    assert records, symbol
    return records
def rpc_union_values(path, symbol, pattern):
    text = source(path); match = re.search(pattern, text); assert match, (path, symbol)
    body = match['body']; records = []
    assert not re.sub(JS_STRING, '', body).strip(' |\r\n\t'), ('Unparsed RPC union', symbol)
    for literal in re.finditer(JS_STRING, body):
        records.append(rpc_value_evidence(path, match.start('body')+literal.start(), ast.literal_eval(literal.group()), 'literal_parameter_or_type_union', symbol))
    assert records, symbol
    return records
def rpc_family_for_site(snippet, line):
    for symbol in ('projectRpcByTool', 'recordRpcByTool', 'p5RpcByTool'):
        if '...'+symbol in snippet: return rpc_map_values(symbol)
    path = RPC_MAP_SOURCES['rpcByTool']
    if line == 382:
        # p5GatewayRpc also receives rpcByTool[name] in the p5-only branch.
        return rpc_helper_literals('p5GatewayRpc') + rpc_map_values('p5RpcByTool')
    if line == 906: return rpc_map_values('rpcByTool')
    if line == 1071:
        return rpc_union_values(path, 'callUserProjectRpc.rpc', r'async function callUserProjectRpc\([\s\S]*?\brpc:\s*(?P<body>'+JS_STRING+r'(?:\s*\|\s*'+JS_STRING+r')*)\s*,')
    if line == 1129:
        return rpc_union_values('apps/clued-cloud/worker/records.ts', 'UserRecordRpc', r'export type UserRecordRpc\s*=\s*(?P<body>[^;]+);')
    raise AssertionError(('New RPC site requires explicit source binding', line, snippet))

runtime_paths = {
 'apps/clued-cloud/evals/public-mcp/a03-contract.mjs': 'OAuth query/claims scope decoding; the source is identified, while actual claim membership belongs to authenticated runtime evidence.',
 'apps/clued-cloud/scripts/two-level-snapshot.mjs': 'Derived effective scope combines record.scope and project identity; inventory the project:<id> family and bind source record/project in Step 6.',
 'apps/clued-cloud/scripts/user-memory-bundle-import.mjs': 'Imported record scope is forwarded after bundle validation; bind the import contract and record provenance, not an invented constant.',
 'apps/clued-cloud/tests/continuity.test.mjs': 'Test helper forwards body.scopes; this is a fixture input site, not evidence of a deployed grant.',
 'apps/clued-cloud/tests/p6-shadow-canary.test.mjs': 'Test scope instance follows project:<projectId>; preserve the template and fixture identity, not an unbounded list of future IDs.',
 'apps/clued-cloud/tests/two-level-snapshot.test.mjs': 'Fixture override or project:<projectId> instance; bind fixture source and naming family in Step 5/6.',
 'kernel/policy/identity-security.mjs': 'request.scope is a policy request/claim comparison operand; Step 6 must bind the request, policy, consumer and negative evidence.',
 'kernel/runtime/external-invocation-ledger.mjs': 'signed_capability.payload is a compound signed capability; the surrounding signature/hash/audience/expiry checks identify its consumer. It is not a scalar capability name.',
 'legacy/local-memory-engine-vnext2/adapters/cli_adapter.py': 'Historical adapter forwards object scope.',
 'legacy/local-memory-engine-vnext2/adapters/truth_adapter.py': 'Historical adapter forwards a caller-selected enforcement capability.',
 'legacy/local-memory-engine-vnext2/clued/auth/engine.py': 'Historical authorization result/cache/provider scope propagation or filtering; actual grants are input-dependent.',
 'legacy/local-memory-engine-vnext2/clued/auth/fake.py': 'Historical fake provider forwards fixture scope values.',
 'legacy/local-memory-engine-vnext2/clued/auth/github_provider.py': 'Historical authentication obtains provider scopes and maps them to memory scopes; no live grant is inferred from this source.',
 'legacy/local-memory-engine-vnext2/clued/auth/provider.py': 'Historical provider stores/serializes supplied scopes.',
 'legacy/local-memory-engine-vnext2/clued/cloud_data/lifecycle.py': 'Historical lifecycle scope forwarding or UUID namespace derived from operation identity.',
 'legacy/local-memory-engine-vnext2/clued/controller.py': 'Historical controller propagates binding/provider scopes into its result and consumer.',
 'legacy/local-memory-engine-vnext2/clued/manifests.py': 'Historical manifest generation/validation reads or serializes its caller-supplied scopes.',
 'legacy/local-memory-engine-vnext2/clued/memory_gate.py': 'Historical write gate forwards target scope.',
 'legacy/local-memory-engine-vnext2/clued/r51/security.py': 'Historical grant stores caller scopes, initializes an empty set, and checks membership; the field site is known but grants are runtime data.',
 'legacy/local-memory-engine-vnext2/memory_engine/consolidation.py': 'Historical consolidation forwards scope to object construction.',
 'legacy/local-memory-engine-vnext2/memory_engine/object_index.py': 'Historical index derives scope from an input object.',
 'legacy/local-memory-engine-vnext2/memory_engine/procedural.py': 'Historical procedural adapter forwards query/write scope.',
 'legacy/local-memory-engine-vnext2/memory_engine/recall_trace.py': 'Historical trace forms/serializes a scope structure from mode/project inputs.',
 'legacy/local-memory-engine-vnext2/memory_engine/schema.py': 'Historical object constructor stores supplied scope.',
 'legacy/local-memory-engine-vnext2/memory_engine/truth/gate.py': 'Historical gate stores the passed enforcement capability.',
 'legacy/local-memory-engine-vnext2/memory_engine/truth/integration.py': 'Historical truth wrapper passes/stores enforcement capability.',
 'legacy/local-memory-engine-vnext2/memory_eval/corpus.py': 'Historical fixture helper accepts scope or defaults to _SCOPE_CURRENT; call-site constants are reviewed separately.',
 'legacy/local-memory-engine-vnext2/memory_eval/make_fixtures.py': 'Historical fixture constructor forwards supplied scope.',
 'legacy/local-memory-engine-vnext2/memory_eval/runner.py': 'Historical runner derives engine_scope from an evaluation case.',
 'legacy/local-memory-engine-vnext2/memory_eval/schema.py': 'Historical evaluation schema reads the supplied case scope.',
 'legacy/local-memory-engine-vnext2/tests/test_memory_v2.py': 'Historical test helper forwards fixture scope.',
 'legacy/local-memory-engine-vnext2/tests/test_project_scope.py': 'Historical test helper forwards case/fixture scope.',
 'legacy/local-memory-engine-vnext2/tests/test_recall_trace.py': 'Historical test helper forwards fixture scope.',
 'legacy/local-memory-engine-vnext2/tests/test_relevance_admission.py': 'Historical test helper forwards fixture scope.',
 'legacy/local-memory-engine-vnext2/tests/test_relevance_admission_r1.py': 'Historical test helper forwards fixture scope.',
 'memory.py': 'Current reader role comes from CLUED_ROLE with a read-only-snapshot default; bind actual authorization, not just the default.',
 'verification_context.py': 'Current verification reads expected_bundle_scope or copies authorization.role; bind the verified trust/authorization object in Step 6.',
 'scripts/clued-naming-inventory-consolidate.py': 'Inventory record namespace is propagated from an enumerated source; this is inventory metadata construction, not an independent runtime grant.',
}

rows = []
for item in data['unresolved']:
    path, line = item['path'], item['line']
    text = source(path)
    snippet = text.splitlines()[line - 1]
    category, reason, values, value_evidence = None, None, None, []
    refs = [ref(path, line=line)]
    if item['rule_id'] == 'module_references':
        category = 'RUNTIME_OR_STEP6_BINDING'
        reason = 'The test imports a generated worker URL with a cache-busting query. The entrypoint is finite; the exact output path/hash and query belong to the test/build run receipt.'
        refs.append(ref(path, symbol='const workerUrl' if 'workerUrl.href' in snippet else 'outfile'))
    elif item['rule_id'] == 'config_names':
        category = 'RUNTIME_OR_STEP6_BINDING'
        reason = 'CI artifact-name template binds an actual commit or negative-case run value; retain the template now and resolve its instance against the CI run.'
    elif path.endswith('/app/chatgpt-auth.ts'):
        category = 'FINITE_STATIC_MAPPING'
        symbol = re.search(r'pathname\s*===\s*(\w+)', snippet).group(1)
        found = re.search(r'const '+symbol+r'\s*=\s*("[^"]+")', text)
        values = [json.loads(found.group(1))]; refs.append(ref(path, symbol='const '+symbol))
        reason = 'Reserved route refers to a same-file immutable literal constant; this is a finite source mapping, with no authorization claim.'
    elif path.endswith('/app/page.tsx'):
        category = 'FINITE_STATIC_MAPPING'; values = ['global', 'project']
        refs += [ref(path, symbol='type RecordLevel'), ref(path, symbol='useState<RecordLevel>')]
        reason = 'The input field uses RecordLevel, whose declared literal union is global/project; runtime selected membership still needs its consumer contract.'
    elif path.endswith('/stage5-legacy-dry-run.mjs'):
        category = 'FINITE_STATIC_MAPPING'; values = ['project', 'global']
        refs.append(ref(path, symbol='function classifyScope'))
        reason = 'classifyScope has a finite project/global result; project_id remains a separately bound instance.'
    elif path.endswith('/user-memory-bundle.mjs'):
        category = 'FINITE_STATIC_MAPPING'; values = ['project', 'global']
        reason = 'The conditional explicitly normalizes the scope to two literal names.'
    elif path.endswith('/p5-real-postgres.test.mjs'):
        category = 'FINITE_STATIC_MAPPING'; values = ['canonical:read', 'canonical:write', 'project:read', 'project:write', 'audit:read']
        reason = 'Two literal SQL-array branches define the fixture scope vocabulary. This does not prove a production grant.'
    elif path.endswith('/project-api.test.mjs'):
        category = 'FINITE_STATIC_MAPPING'
        values = sorted(set(re.findall(r'mockAccountRpc\(\s*[\"\']([^\"\']+)', text)))
        assert values
        reason = 'The expected RPC template belongs to mockAccountRpc; literal call sites bound the test expectation vocabulary.'
        refs.append(ref(path, symbol='function mockAccountRpc'))
    elif path.endswith('/worker/continuity.ts'):
        category = 'FINITE_STATIC_MAPPING'
        if item['rule_id'] == 'code_rpc':
            value_evidence = rpc_family_for_site(snippet, line)
            refs += [{k:v for k,v in evidence.items() if k in {'path','line','column','source_sha256','symbol'}} for evidence in value_evidence]
            values = sorted({evidence['current_name'] for evidence in value_evidence})
            reason = 'Per-site source family extracted only from the actual map values, helper literal arguments or declared parameter/type union. Digit-bearing p5 names are retained; unrelated tokens are not candidates. This finite source family does not prove runtime reachability or authorization.'
        elif item['pointer'] and item['pointer'].startswith('/capabilities/'):
            if item['pointer'].endswith(('/enabled', '/version_attribution')):
                category = 'RUNTIME_OR_STEP6_BINDING'
                reason = 'The compound capability field/key is inventoried; its enablement or version metadata is runtime state, not a missing naming definition.'
                refs.append(ref('apps/clued-cloud/worker/p6.ts', symbol='export function versionAttribution') if item['pointer'].endswith('/version_attribution') else ref('apps/clued-cloud/worker/records.ts', symbol='export function recordsV2Enabled'))
            else:
                symbol = snippet.split(':',1)[1].strip().rstrip(',')
                dep = 'apps/clued-cloud/worker/records.ts' if symbol == 'currentWorkContract' else 'apps/clued-cloud/worker/p6.ts'
                refs.append(ref(dep, symbol='export const '+symbol))
                reason = 'The capability field references an explicit exported contract/policy object. Preserve it as a compound definition and map its fields; do not turn the object or numeric budget into a scalar scope name.'
        else:
            values = ['context:read', 'context:write', 'audit:read']
            refs += [ref(path, symbol='const ALL_SCOPES'), ref(path, symbol='function normalizeScopes')]
            reason = 'The allowed-name set is the literal ALL_SCOPES array; normalization filters against it. Actual issued membership is a Step 6 authorization binding.'
    elif path.endswith('/memory_eval/corpus.py') and re.search(r'scope=_SCOPE_\w+', snippet):
        category = 'FINITE_STATIC_MAPPING'
        symbol = re.search(r'scope=(_SCOPE_\w+)', snippet).group(1)
        values, definition = py_constant(path, symbol); refs.append(definition)
        reason = 'The historical fixture references a same-file static scope structure; mode and project_id retain distinct fields.'
    elif path.startswith('legacy/') and re.search(r'"scopes": SCOPES', snippet):
        category = 'FINITE_STATIC_MAPPING'; values, definition = py_constant(path, 'SCOPES'); refs.append(definition)
        reason = 'The historical test references its local literal scope list; it is not a current grant.'
    elif path.endswith('/clued/installer.py'):
        category = 'FINITE_STATIC_MAPPING'
        values, definition = py_constant('legacy/local-memory-engine-vnext2/clued/manifests.py', 'SCOPES'); refs.append(definition)
        reason = 'The historical installer copies the existing literal manifests.SCOPES tuple.'
    elif path.endswith('/test_r5_k1_contract_freeze.py'):
        category = 'NON_NAME_SYMBOL_HOMONYM'; values = 20
        refs.append(ref('legacy/local-memory-engine-vnext2/clued/errors.py', symbol='EXIT_CAPABILITY ='))
        reason = 'This capability-keyed test dictionary stores numeric process exit code 20, not a capability identity or authorization scope.'
    elif path.endswith('/verify-independent.py') or path == 'scripts/clued-naming-surface-inventory.py':
        category = 'NON_NAME_SYMBOL_HOMONYM'
        reason = 'scope is an inventory configuration document/path variable; the source site remains recorded but it is not a scalar product authorization name.'
    elif path in runtime_paths:
        category = 'RUNTIME_OR_STEP6_BINDING'; reason = runtime_paths[path]
    else:
        raise AssertionError(f'Unreviewed site: {path}:{line}: {snippet}')
    historical = path.startswith('legacy/local-memory-engine-vnext2/')
    if historical: refs.append(ref('legacy/local-memory-engine-vnext2/README.md', line=3))
    rows.append({**item, 'source_sha256': cache[path][1], 'source_line': snippet.strip(),
                 'classification': category, 'review_reason': reason,
                 'candidate_values_or_structure': values, 'candidate_value_evidence': value_evidence, 'definition_refs': refs,
                 'lifecycle_evidence': 'FROZEN_AUDIT_ONLY_BY_DIRECTORY_README' if historical else 'CURRENT_OR_TEST_SOURCE_NO_LIFECYCLE_ACCEPTANCE',
                 'step3_treatment': 'Keep this identified source site, expression digest and classification in inventory; no parser/read failure is waived.',
                 'step5_6_obligation': 'Bind family/structure to existing ownership and typed/runtime contracts as applicable. Historical paths remain audit-only and must not be executed merely to enumerate values.',
                 'authority_effect': 'NONE', 'disposition_status': 'DEVELOPMENT_RULE_REVIEW_NOT_GATE_ACCEPTANCE'})

def canonical_sha256(value):
    return hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode('utf-8')).hexdigest()
for row in rows:
    row['review_site_key'] = canonical_sha256({'scanner_sha256': summary['scanner_sha256'],
        **{key:row[key] for key in ('path','line','column','rule_id','reason','pointer','expression_sha256','source_sha256')}})

supplement = {'schema': 'clued.source-bound-rpc-observations/v1', 'authority_effect': 'NONE',
    'evidence_boundary': summary['evidence_boundary'], 'source_commit': summary['base_commit'],
    'scanner_sha256': summary['scanner_sha256'],
    'producer_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    'not_included_in_primary_scanner_record_count': True,
    'records': rpc_helper_literals('p5GatewayRpc')}
(OUT / 'SupplementalRpcObservations.development.json').write_text(json.dumps(supplement, ensure_ascii=False, indent=2), encoding='utf-8')

counts = dict(collections.Counter(row['classification'] for row in rows))
result = {'schema': 'clued.development-typed-surface-review/v1', 'evidence_boundary': summary['evidence_boundary'],
          'base_commit': summary['base_commit'], 'scanner_sha256': summary['scanner_sha256'],
          'review_generator_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
          'rule_coverage_sha256': canonical_sha256(data['rule_coverage']),
          'primary_observation_records_sha256': canonical_sha256(data['records']),
          'scope_contract_sha256': manifest['artifacts/clued-validation/structure-freeze-prep/naming/NamingSurfaceInventoryScope.json']['content_sha256'],
          'semantic_completeness': 'NOT_PROVEN_NOT_A_STEP3_FAILURE_BY_ITSELF',
          'unresolved_total': len(rows), 'classification_counts': counts, 'unreviewed_sites': 0,
          'source_hashes_verified_against_scanned_manifest': True,
          'remaining_selected_source_read_or_parser_failures': 0,
          'rule_review_conclusion': 'IDENTIFIED_FINITE_OR_DYNAMIC_SITES_FOR_INDEPENDENT_STEP3_RULE_REVIEW',
          'gate_effect': 'NONE; Auth and Library evidence gaps remain outside this review.', 'sites': rows}
(OUT / 'UnresolvedReview.development.json').write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps({'counts': counts, 'total': len(rows), 'sources_verified': len(cache)}, ensure_ascii=False))
