"""Independent metadata reconciliation; never execute historical Clued sources."""
from collections import Counter
import hashlib
import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parent / 'phase2-governance-check'


def load(name):
    return json.loads((ROOT / name).read_text(encoding='utf-8-sig'))


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def key(row):
    return tuple(row.get(k) for k in (
        'path', 'line', 'column', 'rule_id', 'reason', 'pointer', 'expression_sha256'))


summary = load('DevelopmentSummary.json')
inventory = load('TypedSurfaceInventory.development.json')
review = load('UnresolvedReview.development.json')
manifest_list = load('ScannedSourceManifest.development.json')
manifest = {r['path']: r for r in manifest_list}
errors = []
if len(manifest) != len(manifest_list):
    errors.append('Duplicate source manifest paths')
if Counter(map(key, inventory['unresolved'])) != Counter(map(key, review['sites'])):
    errors.append('Reviewed site multiset differs from unresolved observations')
classes = Counter(row['classification'] for row in review['sites'])
if dict(classes) != review['classification_counts']:
    errors.append('Classification counts differ')
rules = {r['rule_id']: r for r in inventory['rule_coverage']}
code_ext = {'.js', '.jsx', '.mjs', '.mts', '.ts', '.tsx', '.py'}
selected = {
    'json_names': {p for p in manifest if Path(p).suffix.lower() == '.json'},
    'package_entries': {p for p in manifest if Path(p).name == 'package.json'},
    'config_names': {p for p in manifest if Path(p).suffix.lower() in {'.yml', '.yaml', '.toml'}},
    'sql_object_declarations': {p for p in manifest if Path(p).suffix.lower() == '.sql'},
    'unsupported_language': {p for p in manifest if Path(p).suffix.lower() in
                             {'.c', '.cc', '.cpp', '.h', '.hpp', '.java', '.go', '.rb', '.rs'}},
}
for rule in ('code_routes', 'code_rpc', 'role_capability_scope'):
    selected[rule] = {p for p in manifest if Path(p).suffix.lower() in code_ext}
selected['module_references'] = selected['code_routes'] | {
    p for p in manifest if Path(p).suffix.lower() == '.ps1'}
record_counts = Counter(r['rule_id'] for r in inventory['records'])
unresolved_counts = Counter(r['rule_id'] for r in inventory['unresolved'])
for name, paths in selected.items():
    rule = rules[name]
    if paths != set(rule['selected_files']) or paths != set(rule['examined_files']):
        errors.append('Rule source denominator/read mismatch: ' + name)
    if len(paths) != rule['selected_file_count'] or len(paths) != rule['examined_file_count']:
        errors.append('Rule stated count mismatch: ' + name)
    if record_counts[name] != rule['extracted_records'] or unresolved_counts[name] != rule['unresolved_sites']:
        errors.append('Rule record/site count mismatch: ' + name)

referenced = {}
for site in review['sites']:
    source_lines = (REPO / site['path']).read_text(encoding='utf-8-sig').splitlines()
    if source_lines[site['line'] - 1].strip() != site['source_line'].strip():
        errors.append('Reviewed source line differs: ' + site['path'] + ':' + str(site['line']))
    refs = [{'path': site['path'], 'line': site['line'], 'source_sha256': site['source_sha256']},
            *site['definition_refs']]
    for ref in refs:
        path = ref['path']
        if path not in manifest or manifest[path].get('content_sha256') != ref['source_sha256']:
            errors.append('Reference not bound to scanned source: ' + path)
            continue
        if path not in referenced:
            full = REPO / path
            referenced[path] = {'expected': ref['source_sha256'], 'actual': sha(full)}
        if referenced[path]['actual'] != ref['source_sha256']:
            errors.append('Referenced source changed after scan: ' + path)
        if not site.get('review_reason') or not site.get('step5_6_obligation'):
            errors.append('Missing disposition explanation: ' + path)
scanner_sha = sha(REPO / 'scripts/clued-naming-surface-inventory.py')
if scanner_sha != summary['scanner_sha256'] or scanner_sha != review['scanner_sha256']:
    errors.append('Scanner SHA256 differs across source/summary/review')

# Independently enumerate the actual literal values of these small, explicit
# maps. Do not confuse every clued_* string in a file with an RPC target.
rpc_source_values = set()
rpc_evidence = []
for filename, symbol in (('projects.ts', 'projectRpcByTool'),
                         ('records.ts', 'recordRpcByTool'), ('p5.ts', 'p5RpcByTool')):
    source_path = 'apps/clued-cloud/worker/' + filename
    source = (REPO / source_path).read_text(encoding='utf-8-sig')
    block = re.search(r'export const ' + symbol + r'\s*=\s*\{([\s\S]*?)\}\s*as const', source)
    if block is None:
        raise ValueError('Review source changed: ' + symbol)
    values = set(re.findall(r':\s*"([^"\n]+)"', block.group(1)))
    rpc_source_values.update(values)
    rpc_evidence.append({'path': source_path, 'symbol': symbol, 'values': sorted(values)})
continuity_path = 'apps/clued-cloud/worker/continuity.ts'
continuity = (REPO / continuity_path).read_text(encoding='utf-8-sig')
helper_values = set(re.findall(r'p5GatewayRpc\(env,\s*"([^"\n]+)"', continuity))
rpc_source_values.update(helper_values)
rpc_evidence.append({'path': continuity_path, 'symbol': 'p5GatewayRpc literal call arguments',
                     'values': sorted(helper_values)})
rpc_missing_observations = sorted(rpc_source_values - {
    r['current_name'] for r in inventory['records'] if r['rule_id'] == 'code_rpc'})
rpc_review_values = {value for row in review['sites']
                     if row['path'] == continuity_path and row['rule_id'] == 'code_rpc'
                     for value in (row['candidate_values_or_structure'] or [])}
rpc_missing_both = sorted(set(rpc_missing_observations) - rpc_review_values)
if rpc_missing_both:
    errors.append('Explicit RPC definitions absent from RPC observations and reviewed mappings: ' + repr(rpc_missing_both))
rpc_family_checks = []
for row in review['sites']:
    if row['path'] == continuity_path and row['rule_id'] == 'code_rpc':
        values = set(row['candidate_values_or_structure'] or [])
        # Only the p5 spread is required to contain its own map members. Full
        # call sites may have narrower call-specific candidate sets after review.
        required = set(next(e['values'] for e in rpc_evidence if e['symbol'] == 'p5RpcByTool')) if row['line'] == 865 else set()
        missing = sorted(required - values)
        if missing:
            errors.append('p5 spread candidate mapping missing explicit values: ' + repr(missing))
        if 'clued_bnd_' in values:
            errors.append('Binding-token prefix mislabeled as an RPC candidate at line ' + str(row['line']))
        rpc_family_checks.append({'line': row['line'], 'candidate_count': len(values),
                                  'missing_required_values': missing,
                                  'token_prefix_mislabeled': 'clued_bnd_' in values})

result = {
    'check_kind': 'INDEPENDENT_METADATA_RECONCILIATION_NOT_SEMANTIC_PROOF',
    'status': 'PASS' if not errors else 'FAIL',
    'scanner_sha256': scanner_sha,
    'tracked_manifest_count': len(manifest_list),
    'typed_observation_count': len(inventory['records']),
    'unresolved_count': len(inventory['unresolved']),
    'reviewed_count': len(review['sites']),
    'classification_counts': dict(classes),
    'referenced_source_count': len(referenced),
    'unique_errors': sorted(set(errors)),
    'rules': [{k: r[k] for k in ('rule_id', 'selected_file_count', 'examined_file_count',
                                'candidate_sites', 'extracted_records', 'unresolved_sites')}
              for r in inventory['rule_coverage']],
    'input_sha256': {name: sha(ROOT / name) for name in (
        'DevelopmentSummary.json', 'TypedSurfaceInventory.development.json',
        'UnresolvedReview.development.json', 'ScannedSourceManifest.development.json')},
    'source_sha256': referenced,
    'rpc_source_values': rpc_evidence,
    'rpc_missing_raw_observations': rpc_missing_observations,
    'rpc_missing_observations_and_review': rpc_missing_both,
    'rpc_candidate_mapping_checks': rpc_family_checks,
}
(ROOT / 'IndependentReview.checks.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
inspection = []
for i, row in enumerate(review['sites'], 1):
    inspection.append(f"{i}. {row['path']}:{row['line']} [{row['rule_id']} / {row['classification']}]\n"
                      f"   {row['source_line']}\n"
                      f"   {row['review_reason']}\n"
                      f"   candidates={json.dumps(row['candidate_values_or_structure'], ensure_ascii=False)}\n"
                      f"   refs={json.dumps(row['definition_refs'], ensure_ascii=False)}")
(ROOT / 'IndependentReview.inspection.txt').write_text('\n'.join(inspection) + '\n', encoding='utf-8')
print(json.dumps({k: v for k, v in result.items() if k not in ('source_sha256', 'input_sha256')}, ensure_ascii=False, indent=2))
raise SystemExit(1 if errors else 0)
