# Clued V15 — Minimum-Cost Local RC Execution Contract

Status: `FROZEN_ON_HASH_BINDING`

## 1. Authority

This contract implements the user's standing instruction:

> 后面还有要停需要我授权的吗 有就改合同

Observed authority quote SHA-256: `ed0d9be72b73f92ee422ef48d7cd84ab02d48d9a2902b62f583a0f97f7834abf`.

The user's latest correction, observed at `2026-09-02T05:09:49.1359967Z`, is:

> 改个合同都这么难吗

Correction quote SHA-256: `d795354555c006379719a0441ac0e2a241fcf82bcb8098b5b05a7c9c9a376e8b`.

Authority ID: `auth_clued_v15_minimum_cost_local_rc_20260902`.

Objective: finish the local, non-production Clued Kernel Next implementation/RC plan through V17 with the minimum truthful control overhead and no repeated user-authorization pauses.

## 2. Precedence and preserved history

For all future work, this contract supersedes the execution/control mechanics of v4–v14. All prior contracts, candidates, attempts, reviews and evidence remain immutable historical evidence; none may be rewritten or deleted.

The v14 operational-root source is classified `UNEXECUTED_DRAFT / NO_AUTHORITY_CONSUMPTION / NO_TARGET_WRITE`. It must not be run. No v14 DPAPI key, operational root, lease, consumption record or external effect exists.

The completed G0a evidence remains valid historical baseline evidence. It is not rerun and its consumed GA is never reused.

## 3. Control simplification

For this local RC track, the following are abolished and are not prerequisites:

- Control Trust Root or operational-root bootstrap;
- signed StatusManifest, GateDefinition, GateAuthorization or GateResultReceipt;
- per-Gate or per-attempt user authorization;
- one-time execution opportunity, latch, authority consumption or automatic E1 coupling;
- DPAPI signer custody, separate Windows signer account, scheduled task registration, run/call journal or registration directory;
- PromotionAuthorization/PromotionResultReceipt;
- cryptographic continuity between local work packages;
- a new contract revision merely because a local test or implementation attempt failed.

The labels `G0b`, `G1`, `G2`, `G3`, `G4f`, `G4a-B`, `G4a-D`, `G4b`, `G5a`, `G5b`, `G5c`, `G6a`, `G6b`, `PERF-S`, `MIG-Q` and `G7A` remain acceptance-checklist labels only. They are not authorization objects and do not require signing or a unique irreversible launch.

v3.3 and v1.5 remain design/acceptance sources. Their signed control-plane mechanics are explicitly not claimed as implemented by this track. No result may say `v3.3 cryptographic Gate conformance`.

## 4. Standing local authority

Without asking the user again, the coordinator may:

- read the workspace, target repository, frozen evidence, local tool caches and remote Git state;
- edit local source, tests, workflows, schemas, documentation and local-only configuration;
- create local commits on the existing candidate branch;
- run local tests, linters, deterministic builds, mocks, fixtures, isolated databases and zero-cost local services;
- download a version-pinned, license-known, zero-cost public dependency when necessary;
- reuse existing content-addressed candidates and test outputs;
- retry after a changed mechanism or changed candidate;
- generate local RC, BOM/SBOM, test reports and V17 acceptance evidence;
- use one coordinator and up to three bounded parallel lanes.

Allowed write roots:

1. the current workspace;
2. `C:\Users\17531\.codex\projects\codex-memory-system`;
3. `C:\Users\17531\AppData\Local\Temp\clued-kernel-next-v33-v15`.

These actions are ordinary `LOCAL_REVERSIBLE_EFFECT`. There is no authority-consumption event.

## 5. Hard prohibitions

This contract does not authorize:

- remote Git push, merge, tag, release or publication;
- production deployment, traffic, DNS, Pointer or live configuration change;
- authenticated Canonical Store mutation or `memory/` business write;
- live database/Schema/Secret/KMS mutation;
- external provider, customer account, Portal or public plugin mutation;
- paid service, paid dependency, usage-reset credit or new recurring/background Codex task;
- destructive deletion or rewriting of prior evidence;
- a production, published, deployed or cryptographic-Gate-conformance claim.

Crossing any of these boundaries requires a separate future instruction. Their absence does not block V17 local acceptance.

## 6. Evidence model

Each work package produces one ordinary, unsigned, content-addressed `WorkPackageReceipt` containing:

- package ID and predecessor package IDs;
- source contract digest;
- input commit/tree or content-tree digest;
- files actually changed;
- commands/tests actually run and exit results;
- output/evidence digests;
- result: `PASS`, `FAIL`, `BLOCKED` or `N/A_WITH_PROOF`;
- known residual risks and the next package.

Receipts are append-only files. SHA-256 and Git commit/tree identity provide integrity; no signature, GA, GRR, Trust Root, lease or latch is required.

A failed receipt does not poison the task, consume a unique opportunity or force rollback. A new candidate may proceed when it has a new digest and a materially changed mechanism.

## 7. Cost and retry rules

- Never repeat an unchanged failing command on unchanged bytes more than once.
- After one repeat, change the mechanism, narrow the test or split the package.
- At most two mechanism-changing repairs per package before emitting a precise blocker and moving to an independent package that can still progress.
- Reuse existing candidates, dependency caches and evidence before generating new artifacts.
- Run the smallest relevant test first; run the full applicable suite once at package close.
- Perform one independent review at G0b close, one at aggregate V15, and one at V17; do not review every intermediate edit.
- Parallel lanes may research/test independent files, but only the coordinator integrates and commits.
- Budget exhaustion is handled by package splitting, not by asking for the same authorization again.

## 8. Applicability reductions

The minimum local RC profile is fixed:

- provider: `none`;
- data: synthetic/local fixtures only;
- Windows UIA: `N/A_WITH_PROOF` unless already required by implemented code;
- real external Model Provider: `N/A_WITH_PROOF`;
- production migration and production-equivalent environment: `N/A_WITH_PROOF`;
- public Plugin/Portal submission: `N/A_WITH_PROOF`;
- live Sentry/telemetry backend: `N/A_WITH_PROOF`;
- paid load infrastructure: forbidden; local deterministic load/fault fixtures only;
- two-host test: use two already-available zero-cost local execution identities/process hosts; do not purchase or provision infrastructure.

Optional capability absence does not block core local RC when its boundary and fallback are tested.

## 9. Execution chain

The coordinator proceeds continuously:

`G0b governance receipt → contract-toolchain package → G1/core contract package → V00/V01/V01A → applicable V02–V14 packages → aggregate V15 → V16 N/A proof → independent V17 review`.

G0b may reuse the existing nine-ADR candidate plus r2 corrections. It closes when required ADR topics, CI-47, CI-48 and EIA-40.a have current local evidence and one independent review; no signed control objects or dependency-site recrawl are required unless implementation actually imports that dependency.

The contract-toolchain package may reuse existing staged compiler/schema/fixture assets. It needs deterministic generation and negative-fixture evidence, not a signed bootstrap attestation.

No package PASS automatically claims production readiness. It only unlocks the next local package under this standing authority.

## 10. Stop conditions

Execution stops only when:

- an actual or uncertain external/production effect occurs;
- incremental monetary cost is nonzero or unknown;
- a secret/private credential is exposed;
- prior evidence would need destructive rewriting;
- the target repository or required local source becomes unavailable;
- a mandatory core test proves a real invariant failure that cannot be repaired within two changed mechanisms;
- the user explicitly revokes or changes scope.

A normal local test failure, missing signed Gate object, missing Trust Root, expired local budget window, absent scheduled task, empty registration/run directory, or previous attempt is not a stop condition and never requires new user authorization.

## 11. Final claims

V16 closes as:

`NOT_AUTHORIZED / N/A_WITH_PROOF / NO_PRODUCTION_CLAIM`.

V17 may close only after independent review of the same local candidate, receipts, applicable tests and residual risks. The maximum claim is:

`CLUED_KERNEL_NEXT_LOCAL_IMPLEMENTATION_ACCEPTED_UNDER_V15 / LOCAL_RC_ONLY`.

It must not claim production authorization, deployment, publication, public availability or v3.3 cryptographic Gate conformance.

This contract becomes effective immediately when a separate manifest binds its exact byte length and SHA-256. No additional independent contract review or user confirmation is required before execution.
