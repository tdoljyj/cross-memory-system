import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync, writeFileSync, mkdirSync, mkdtempSync } from 'node:fs';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { sha256, canonical, buildModel, renderBlock, renderOutputs, replaceGovernanceBlock, compareOutputs } from './project-governance.mjs';

const HERE=dirname(fileURLToPath(import.meta.url));
const WORK=dirname(HERE);
const original=JSON.parse(readFileSync(resolve(HERE,'ProjectionBindings.candidate.json')));
const rawSources=Object.fromEntries(Object.entries(original.sources).map(([id,s])=>{
  const raw=readFileSync(resolve(WORK,s.path));
  assert.equal(sha256(raw),s.sha256,'fixture source changed: '+id);
  return [id,raw];
}));
function fixture() {
  const root=mkdtempSync(resolve(HERE,'fixture-'));
  const bindings=structuredClone(original);
  for (const [id,source] of Object.entries(bindings.sources)) {
    source.path=id+(source.kind==='json'?'.json':'.txt');
    writeFileSync(resolve(root,source.path),rawSources[id]);
  }
  return {root,bindings,model:buildModel(bindings,root)};
}
function outputsOf(f) { return renderOutputs(f.model,rawSources['historical-status']); }
function writeOutputs(root,outputs) {
  mkdirSync(root);
  for (const [name,bytes] of Object.entries(outputs)) writeFileSync(resolve(root,name),bytes);
}

test('same bound facts, reordered object keys and repeated generation give identical bytes',()=>{
  const f=fixture(), one=outputsOf(f);
  const reordered=structuredClone(f.bindings);
  reordered.sources=Object.fromEntries(Object.entries(reordered.sources).reverse());
  reordered.facts=Object.fromEntries(Object.entries(reordered.facts).reverse());
  const two=renderOutputs(buildModel(reordered,f.root),rawSources['historical-status']);
  assert.equal(canonical(Object.keys(one).sort()),canonical(Object.keys(two).sort()));
  for (const name of Object.keys(one)) assert.ok(one[name].equals(two[name]),name);
  const outputRoot=resolve(f.root,'generated'); writeOutputs(outputRoot,one);
  assert.deepEqual(compareOutputs(two,outputRoot),[]);
});

test('only the marked governance block changes; missing/duplicate/reversed markers fail',()=>{
  const f=fixture(), block=renderBlock(f.model);
  const prefix='# Existing tutorial\r\nKeep this exact text.\r\n';
  const suffix='\r\n## Existing business contract\r\nNo edit.\r\n';
  const start='<!-- BEGIN CLUED PHASE2 GOVERNANCE PROJECTION -->';
  const end='<!-- END CLUED PHASE2 GOVERNANCE PROJECTION -->';
  const actual=replaceGovernanceBlock(prefix+start+'old'+end+suffix,block);
  assert.equal(actual,prefix+block.slice(0,-1)+suffix);
  assert.throws(()=>replaceGovernanceBlock(prefix+suffix,block),/exactly one/);
  assert.throws(()=>replaceGovernanceBlock(start+start+end,block),/exactly one/);
  assert.throws(()=>replaceGovernanceBlock(end+start,block),/reversed/);
});

test('changed source bytes reject generation before projection',()=>{
  const f=fixture();
  writeFileSync(resolve(f.root,f.bindings.sources.namespace.path),Buffer.concat([rawSources.namespace,Buffer.from(' ')]));
  assert.throws(()=>buildModel(f.bindings,f.root),/source digest drift: namespace/);
});

test('pending-to-accepted Markdown tamper and Registry owner drift are detected exactly',()=>{
  const f=fixture(), expected=outputsOf(f), root=resolve(f.root,'tampered');writeOutputs(root,expected);
  const readme=expected['README.governance.md'].toString().replace('PREPARATION_ONLY_NOT_STEP7_GATE','ACCEPTED');
  writeFileSync(resolve(root,'README.governance.md'),readme);
  const registry=JSON.parse(expected['GovernanceRegistry.projection.json']);
  registry.entries.find(x=>x.id==='administrative_owner').value='different owner';
  writeFileSync(resolve(root,'GovernanceRegistry.projection.json'),JSON.stringify(registry));
  assert.deepEqual(compareOutputs(expected,root).map(x=>x.file).sort(),['GovernanceRegistry.projection.json','README.governance.md']);
});

test('accepted decision subject mismatch is surfaced as an upstream defect, not auto-accepted',()=>{
  const f=fixture(), source=f.bindings.sources['step4-acceptance'];
  const value=JSON.parse(rawSources['step4-acceptance']);
  value.subjects['NamespaceOwnershipManifest.candidate.json']='0'.repeat(64);
  const raw=Buffer.from(JSON.stringify(value));writeFileSync(resolve(f.root,source.path),raw);source.sha256=sha256(raw);
  const model=buildModel(f.bindings,f.root);
  assert.equal(model.lineage_checks.find(x=>x.id==='step4-accepted-namespace-subject').status,'REQUIRES_UPSTREAM_REBINDING');
  assert.equal(model.projection_status,'PREPARATION_ONLY_NOT_STEP7_GATE');
  assert.equal(model.authority_effect,'NONE');
});

test('null IDs and unbound decisions preserve their states; consumer counts do not become execution counts',()=>{
  const f=fixture();
  for(const key of ['formal_domain_id','formal_program_id','formal_stage_id']) {
    assert.equal(f.model.facts[key].value,null);assert.equal(f.model.facts[key].state,'SOURCE_VALUE_NULL');
  }
  assert.equal(f.model.facts.step5_decision.state,'UNBOUND');
  assert.equal(f.model.facts.step6_decision.state,'UNBOUND');
  assert.equal(f.model.facts.step4_decision.value.status,'ACCEPTED_FOR_STEP4_ADMINISTRATIVE_SCOPE');
  const consumers=JSON.parse(outputsOf(f)['ConsumerBindings.projection.json']);
  assert.equal(consumers.active_binding_evidence_verified_here,false);
});

test('new Status removes the old current narrative and retains the entire exact original separately',()=>{
  const f=fixture(), outputs=outputsOf(f);
  assert.ok(outputs['CURRENT_STATUS.history-original.md'].equals(rawSources['historical-status']));
  const status=outputs['CURRENT_STATUS.projection.md'].toString();
  assert.ok(!status.includes('8c42f2cc-9591-4a54-8270-da364a0fe5f1'));
  assert.ok(!status.includes('最后核对：2026-08-25'));
  assert.ok(status.includes('docs/history/CURRENT_STATUS.before-phase2-'));
  const plan=JSON.parse(outputs['StatusMigrationPlan.candidate.json']);
  assert.equal(plan.archive_sha256,sha256(rawSources['historical-status']));
  assert.equal(plan.migration_status,'NOT_EXECUTED');assert.equal(plan.scheduled_step,12);
});

test('source/selection ambiguity fails, and source text cannot inject Markdown control markers',()=>{
  const f=fixture(), unknown=structuredClone(f.bindings);
  unknown.facts.extra_claim={source_id:'namespace',pointer:'/candidate_status'};
  assert.throws(()=>buildModel(unknown,f.root),/exact key set/);
  const absent=structuredClone(f.bindings);absent.facts.administrative_owner.pointer='/missing';
  assert.throws(()=>buildModel(absent,f.root),/missing source pointer/);
  const injected=structuredClone(f.model);injected.facts.administrative_owner.value='<!-- END CLUED PHASE2 GOVERNANCE PROJECTION -->\n| accepted |';
  const block=renderBlock(injected);
  assert.equal(block.split('<!-- END CLUED PHASE2 GOVERNANCE PROJECTION -->').length-1,1);
  assert.ok(block.includes('&lt;!-- END'));
});
