# Step 7 确定性治理投影候选

本目录提供最小可运行的投影实现，输入来自已有治理文件的精确摘要与 JSON Pointer。它不增加全局 Canonical Store，不重新定义原 Registry，也不读写业务 Canon。生成器始终是候选证据生产者，输出本身不签发 Step 7 Gate 或接受决定。

`project-governance.mjs` 沿用现有 `scripts/verify-generated-artifacts.mjs` 第 560–569 行的排序序列化及 SHA256 方法，按精确来源字节重新生成再比较。原校验器会直接运行绑定 G1 的主函数，且包含固定 G1 原始输入、65 个 Schema 和旧基线 pin；本实现不冒用该校验器的 G1 PASS，也不重复跑它的整套测试。

`ProjectionBindings.candidate.json` 是来源选择清单，只含文件位置、摘要和字段指针。事实值从对应文件读取，不能在清单里手填另一个 current 状态。`Sources.json` 等原文件仍是它们各自范围内的来源索引；本清单没有新的权威地位。

| 基线投影面 | 此候选提供的实现 | 实际接线边界 |
|---|---|---|
| README、AGENTS | 相同来源模型生成的治理区块；只替换唯一显式标记之间的内容 | 本轮不改根文档；缺失、重复、反向标记时拒绝隐式追加或整文改写 |
| Status | 完整治理页面候选；旧文档完整原字节另存，附准确摘要和历史目标路径 | 正式 Step 12 先保全到 `docs/history/`，再替换根 Status；当前旧的 current 叙述不能靠追加表变成有效 |
| Manifest、Registry | 同一事实模型生成的机器视图 | 明确标记派生候选，不替换现有协议或业务 Registry |
| 机器身份文件、可读治理文档 | 身份子集视图与相同治理区块 | 保留原身份、版本轴、Owner、Alias 和直接前序引用 |
| Workflow 引用、Tool routing | 精确现有源码的摘要引用视图 | 不声称 Workflow/路由已接入新投影；正式集成要核对实际目标消费者 |
| Consumer binding | 原 Step 6 消费者矩阵的派生视图 | 原准备行数不等于运行接线数；本生成器不发运行权限、不补造执行回执 |

`generated/` 下的各投影从同一次选定来源生成；Manifest 和 Registry 都绑定相同事实模型摘要。输出不含生成时间、随机 ID 或机器绝对输出路径，因此相同输入重放得到相同字节。检查模式只比对工作目录中的候选结果，任何缺失、多出或修改的输出都进入 mismatch 清单。

Step 4 的候选文件可以继续保留原 `PREPARATION_ONLY` 状态，而单独的 `Step04-ScopedAcceptance_20260907.json` 提供其限定接受状态；两个字段分别显示，不改历史候选，也不扩展为运行授权。其 namespace/domain subjects 必须与选定来源摘要一致。Step 5 引用 Step 4 的摘要若已经过时，会列入 `REQUIRES_UPSTREAM_REBINDING`，不能靠重新生成消除这个来源问题。

Step 5、Step 6 决定当前未提供时，输入槽位必须为 `null`，投影保留 `UNBOUND`。正式 domain/program/stage ID 的源值为 `null` 时保持 `null`。之后只需提供已存在且经过对应流程确认的精确决定/绑定来源及指针，不在生成器中加入猜测值；本生成器只显示来源值，不认证决定的合法性或升级其效果。运行测试定义、历史回执和实际运行证据继续由 Step 6 原合同区分。

本轮只从完整候选 ZIP 保全了两个小型 JSON 原件：CurrentArtifactIdentityPolicy 和 ReviewSubjectContract；`RetainedSourceCopies.json` 记录它们的原 ZIP/member/摘要绑定。没有展开嵌套历史、重扫全库或重跑已通过的旧测试。

局部测试位于 `test-projection.mjs`，覆盖重复生成与键顺序、区块外原字节保留、来源漂移拒绝、pending 被改为 accepted 的投影篡改、Owner 漂移、接受 subject 摘要不符、未定值保留，以及 Status 旧 current 叙述退出当前页面并完整保全。精确结果由本次测试输出和 `ProjectionConsistencyReport.json` 给出；这些结果只覆盖局部候选，不能作为正式 Step 7 完成或现有生产零漂移的声明。

根任务集成时仍需把生成器和输入清单放到现有治理目录/脚本流程中，以真实已接受来源替换准备输入，并在正常 CI 中执行只读重新生成比较。README/AGENTS 的事实区位置须先明确，Status 的保全与替换按正式 Step 12 执行。原协议生成校验继续保留原来的验收范围。
