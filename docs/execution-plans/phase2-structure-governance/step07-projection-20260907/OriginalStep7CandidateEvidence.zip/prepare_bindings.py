"""Capture selected existing governance inputs; no scan, decisions or repo writes."""
import hashlib
import json
from pathlib import Path
import zipfile

OUT=Path(__file__).resolve().parent
WORK=OUT.parent
REPO=WORK/'phase2-governance-check'
DOCS=REPO/'docs/execution-plans/phase2-structure-governance'
OUT.joinpath('inputs').mkdir(exist_ok=True)
sources={}
def add(key,path,kind='json'):
    raw=path.read_bytes()
    sources[key]={'path':path.relative_to(WORK).as_posix(),'sha256':hashlib.sha256(raw).hexdigest(),'kind':kind}
    return json.loads(raw) if kind=='json' else raw.decode('utf8')
def select(key,pointer=''):
    return {'source_id':key,'pointer':pointer}

s4=DOCS/'step04-namespace-20260907'
add('namespace',s4/'NamespaceOwnershipManifest.candidate.json')
add('domains',s4/'DomainRegistryOwnershipManifest.candidate.json')
add('step4-acceptance',DOCS/'Step04-ScopedAcceptance_20260907.json')
add('delegation',DOCS/'ExecutionDelegation_20260907.json')
add('versions',WORK/'step5-identity-candidate/VersionAxisRegistry.candidate.json')
add('aliases',WORK/'step5-identity-candidate/AliasRegistry.candidate.json')
add('step5-source-index',WORK/'step5-identity-candidate/Sources.json')
add('consumers',WORK/'step6-consumer-candidate/ConsumerMatrix.json')
add('workflow',REPO/'.github/workflows/phase2-naming-surface-inventory.yml','text')
add('tool-routing',REPO/'AGENTS.md','text')
add('historical-status',REPO/'CURRENT_STATUS.md','text')
add('existing-verifier',REPO/'scripts/verify-generated-artifacts.mjs','text')

original_sources=json.loads((WORK/'step5-identity-candidate/Sources.json').read_text(encoding='utf8'))['sources']
copied={}
for key in ['identity-policy','review-subject']:
    s=original_sources[key]
    with zipfile.ZipFile(s['archive_path']) as z:
        raw=z.read(s['member'])
    assert hashlib.sha256(raw).hexdigest()==s['sha256']
    target=OUT/'inputs'/Path(s['member']).name
    target.write_bytes(raw)
    add(key,target)
    copied[key]={'original_source':s,'retained_copy':sources[key], 'byte_identity_verified':True}

facts={
 'step4_candidate_status':select('namespace','/candidate_status'),
 'administrative_owner':select('delegation','/delegator'),
 'namespace_groups':select('namespace','/namespaces'),
 'domain_registry_policy':select('domains','/canonical_governance_registry_policy'),
 'step5_candidate_status':select('versions','/candidate_status'),
 'version_axes':select('versions','/axes'),
 'stable_map_identity':select('versions','/scope/target_map_id'),
 'new_alias_entries':select('aliases','/new_runtime_alias_entries'),
 'direct_predecessor':select('review-subject','/sole_direct_predecessor'),
 'historical_namespaces_cannot_issue_current_state':select('identity-policy','/historical_namespaces_cannot_issue_current_state'),
 'step6_candidate_status':select('consumers','/status'),
 'formal_domain_id':select('consumers','/formal_domain_id'),
 'formal_program_id':select('consumers','/formal_program_id'),
 'formal_stage_id':select('consumers','/formal_stage_id'),
 'consumer_count':select('consumers','/consumer_count'),
 'consumer_bindings':select('consumers','/consumers'),
 'step4_decision':select('step4-acceptance'),
 'step5_decision':None,
 'step6_decision':None,
}
lineage=[
 {'id':'step4-accepted-namespace-subject','expected_digest':select('step4-acceptance','/subjects/NamespaceOwnershipManifest.candidate.json'),'target_source_id':'namespace'},
 {'id':'step4-accepted-domain-subject','expected_digest':select('step4-acceptance','/subjects/DomainRegistryOwnershipManifest.candidate.json'),'target_source_id':'domains'},
 {'id':'step5-upstream-namespace','expected_digest':select('step5-source-index','/sources/step4-ownership/sha256'),'target_source_id':'namespace'},
 {'id':'step5-upstream-domain','expected_digest':select('step5-source-index','/sources/step4-domains/sha256'),'target_source_id':'domains'},
]
bindings={'format':'SOURCE_REFERENCE_SELECTIONS_NOT_CANONICAL_REGISTRY','authority_effect':'NONE','sources':sources,'facts':facts,'lineage_checks':lineage}
(OUT/'ProjectionBindings.candidate.json').write_text(json.dumps(bindings,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
(OUT/'RetainedSourceCopies.json').write_text(json.dumps(copied,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
print(json.dumps({'sources':len(sources),'facts':len(facts),'lineage_checks':len(lineage),'selected_zip_copies':len(copied),'repository_writes':0}))
