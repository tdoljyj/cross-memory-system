"""Only isolated synthetic work directories are mutated; real repo is read-only."""
import hashlib
import io
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

from migration_preflight import preflight, rollback_preflight, resolve_history, safe_path

OUT=Path(__file__).resolve().parent
WORK=OUT.parent
REPO=WORK/'phase2-governance-check'
PLAN=json.loads((OUT/'MigrationPlan.candidate.json').read_text(encoding='utf8'))
HISTORY=json.loads((OUT/'HistoryPathMap.candidate.json').read_text(encoding='utf8'))
GIT='C:/Users/Windows/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/git/cmd/git.exe'
NODE='C:/Users/Windows/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node.exe'
PWSH='C:/Users/Windows/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/powershell/pwsh.exe'
FIXTURES=OUT/'fixtures';FIXTURES.mkdir(exist_ok=True)
def sha(raw):return hashlib.sha256(raw).hexdigest()
def original(name):return subprocess.check_output([GIT,'-c',f'safe.directory={REPO}','-C',str(REPO),'show',PLAN['source_commit']+':'+name])
ORIGINALS={op['source']['path']:original(op['source']['path']) for op in PLAN['operations']}
def write(root,name,data):
    p=safe_path(root,name);p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
def make_fixture():
    root=Path(tempfile.mkdtemp(prefix='repo-',dir=FIXTURES))
    for name,raw in ORIGINALS.items():write(root,name,raw)
    return root
def fixture_guard(root):
    if not root.resolve().is_relative_to(FIXTURES.resolve()) or (root/'.git').exists():raise ValueError('fixture mutation boundary')
def apply_fixture(root):
    fixture_guard(root)
    assert not preflight(PLAN,root,OUT)['errors']
    for op in PLAN['operations']:
        if op['kind']=='MOVE_EXACT_BYTES':
            target=safe_path(root,op['target']);target.parent.mkdir(parents=True,exist_ok=True)
            safe_path(root,op['source']['path']).rename(target)
        elif op['kind']=='PRESERVE_BASELINE_THEN_PROJECT':
            write(root,op['archive_target'],safe_path(root,op['source']['path']).read_bytes())
        elif op['kind']=='MOVE_IMPLEMENTATION_WITH_COMPATIBILITY':
            for field in ['target_implementation','compatibility_entry']:
                item=op[field];write(root,item['path'],(OUT/item['payload_path']).read_bytes())
        elif op['kind']=='UPDATE_SPECIFIC_CALLER_COPY_SET':
            item=op['replacement'];write(root,item['path'],(OUT/item['payload_path']).read_bytes())
def after_receipt(root):
    affected=set(ORIGINALS)
    for op in PLAN['operations']:
        if op['kind']=='MOVE_EXACT_BYTES':affected.add(op['target'])
        elif op['kind']=='PRESERVE_BASELINE_THEN_PROJECT':affected.add(op['archive_target'])
        elif op['kind']=='MOVE_IMPLEMENTATION_WITH_COMPATIBILITY':affected.add(op['target_implementation']['path'])
    return {'scope':'ISOLATED_FIXTURE_ONLY_NOT_ACTUAL_MIGRATION_RECEIPT','after_files':[
        {'path':p,'sha256':sha(safe_path(root,p).read_bytes()) if safe_path(root,p).is_file() else None} for p in sorted(affected)]}
def restore_fixture(root,receipt):
    fixture_guard(root)
    check=rollback_preflight(receipt,root)
    if check['errors']:raise ValueError('rollback after-state drift')
    for item in receipt['after_files']:
        p=safe_path(root,item['path'])
        if item['path'] in ORIGINALS:write(root,item['path'],ORIGINALS[item['path']])
        elif p.is_file():p.unlink()
def run_python(root,path,*args):
    env=os.environ.copy();env['PYTHONIOENCODING']='utf-8';env['PYTHONDONTWRITEBYTECODE']='1'
    return subprocess.run([sys.executable,str(root/path),*args],cwd=root.parent,env=env,capture_output=True,text=True,encoding='utf8')

class FixtureChecks(unittest.TestCase):
    def test_19_historical_moves_preserve_original_bytes_and_rollback(self):
        root=make_fixture();apply_fixture(root)
        for entry in HISTORY['entries']:
            self.assertFalse((root/entry['original']['path']).exists())
            self.assertEqual(entry['target_sha256'],sha((root/entry['target']).read_bytes()))
        receipt=after_receipt(root);self.assertFalse(rollback_preflight(receipt,root)['errors'])
        restore_fixture(root,receipt)
        for name,raw in ORIGINALS.items():self.assertEqual(raw,(root/name).read_bytes())
        for entry in HISTORY['entries']:self.assertFalse((root/entry['target']).exists())

    def test_collision_source_drift_and_protected_path_fail_preflight(self):
        root=make_fixture();write(root,HISTORY['entries'][0]['target'],b'occupied')
        self.assertTrue(any(x['reason']=='TARGET_ALREADY_EXISTS' for x in preflight(PLAN,root,OUT)['errors']))
        name=PLAN['operations'][0]['source']['path'];write(root,name,b'changed')
        self.assertTrue(any(x['reason']=='SOURCE_DRIFT' for x in preflight(PLAN,root,OUT)['errors']))
        for p in ['../outside','memory/manifest.json','apps/worker.ts','artifacts/current.json']:
            with self.assertRaises(ValueError):safe_path(root,p)

    def test_rollback_refuses_concurrent_change(self):
        root=make_fixture();apply_fixture(root);receipt=after_receipt(root)
        path=HISTORY['entries'][0]['target'];write(root,path,b'concurrent work')
        self.assertEqual('BLOCKED_BY_DRIFT',rollback_preflight(receipt,root)['rollback_preflight'])
        with self.assertRaisesRegex(ValueError,'drift'):restore_fixture(root,receipt)
        self.assertEqual(b'concurrent work',(root/path).read_bytes())

    def test_old_and_direct_python_entries_preserve_output_exit_and_zero_read_paths(self):
        root=make_fixture();apply_fixture(root)
        cases=[('memory.py',['--help'],0),('memory.py',['add','fixture'],2),
               ('memory.py',['recall','generic','--tier','T0'],0),
               ('sync-memory.py',['align-and-verify','NONE'],0),('sync-memory.py',['fixture-unknown-mode'],1)]
        for name,args,code in cases:
            with self.subTest(name=name,args=args):
                old=run_python(root,name,*args);direct=run_python(root,'scripts/'+name,*args)
                self.assertEqual(code,old.returncode,old.stderr);self.assertEqual(code,direct.returncode,direct.stderr)
                self.assertEqual(old.stdout,direct.stdout);self.assertEqual(old.stderr,direct.stderr)
        self.assertFalse((root/'memory').exists())

    def test_module_file_globals_and_dual_source_identity(self):
        root=make_fixture();apply_fixture(root)
        code='''import importlib.util,sys,json,inspect
from pathlib import Path
root=Path(sys.argv[1]);sys.path.insert(0,str(root))
import memory,canonical_read,isolated_mirror,verification_context
spec=importlib.util.spec_from_file_location("fixture_sync",root/"sync-memory.py")
sync=importlib.util.module_from_spec(spec);spec.loader.exec_module(sync)
assert memory.REPO==root and sync.REPO==root
assert memory.MEMORY==root/"memory"
for module,name in [(memory,"memory.py"),(canonical_read,"canonical_read.py"),(isolated_mirror,"isolated_mirror.py"),(verification_context,"verification_context.py"),(sync,"sync-memory.py")]:
 assert Path(module.__file__)==root/"scripts"/name
memory.validate_bundle=lambda *a,**k: ("patched_same_globals",[])
assert sync.validate(root/"unused")==("patched_same_globals",[])
assert Path(inspect.getsourcefile(memory.cmd_retired))==root/"scripts/memory.py"
assert memory.cmd_retired.__globals__ is memory.__dict__
assert sync.validate.__globals__ is sync.__dict__
print(json.dumps({"repo_root":str(root),"monkeypatch":"preserved","implementation_file":"visible"}))
'''
        env=os.environ.copy();env['PYTHONDONTWRITEBYTECODE']='1'
        result=subprocess.run([sys.executable,'-c',code,str(root)],cwd=root.parent,env=env,capture_output=True,text=True)
        self.assertEqual(0,result.returncode,result.stderr)
        for tool in json.loads((OUT/'ToolCompatibilityPlan.candidate.json').read_text(encoding='utf8'))['tools']:
            for key in ['compatibility_entry','target_implementation']:
                bound=tool[key];self.assertEqual(bound['sha256'],sha((root/bound['path']).read_bytes()))

    def test_powershell_parameter_config_root_and_exitcode_forwarding(self):
        root=make_fixture();apply_fixture(root)
        write(root,'sync.config.ps1',b'$MemoryDir = "fixture-memory-root"\n')
        shell='''function global:python { $values=@($args); [pscustomobject]@{argv=$values; memory=$env:CROSS_MEMORY_LOCAL_DIR} | ConvertTo-Json -Compress; $global:LASTEXITCODE=7 }; & $args[0] -Pull -Access NONE; exit $LASTEXITCODE'''
        write(root,'_ps1_contract_probe.ps1',shell.encode('utf8'))
        results=[]
        for entry in ['sync-memory.ps1','scripts/sync-memory.ps1']:
            result=subprocess.run([PWSH,'-NoProfile','-File',str(root/'_ps1_contract_probe.ps1'),str(root/entry)],cwd=root.parent,capture_output=True,text=True,encoding='utf8')
            self.assertEqual(7,result.returncode,result.stderr);results.append(json.loads(result.stdout))
        self.assertEqual(results[0],results[1]);self.assertEqual('fixture-memory-root',results[0]['memory'])
        self.assertEqual(['align-and-verify','NONE'],results[0]['argv'][1:])
        self.assertEqual(root/'scripts/sync-memory.py',Path(results[0]['argv'][0]))

    def test_specific_existing_caller_package_contains_implementations(self):
        root=make_fixture();apply_fixture(root)
        text=(root/'tests/test_p2_verification_context.py').read_text(encoding='utf8')
        for tool in json.loads((OUT/'ToolCompatibilityPlan.candidate.json').read_text(encoding='utf8'))['tools']:
            self.assertIn('"'+tool['target_implementation']['path']+'"',text)
        self.assertIn('(repo / name).parent.mkdir(parents=True, exist_ok=True)',text)

    def test_history_links_resolve_against_original_commit_not_new_directory(self):
        first=HISTORY['entries'][0];other=HISTORY['entries'][1]
        result=resolve_history(HISTORY,first['target'],other['original']['path']+'#section')
        self.assertEqual(PLAN['source_commit'],result['commit']);self.assertEqual(other['target'],result['mapped_current_path'])
        self.assertEqual(other['original']['path'],result['original_target_path']);self.assertEqual('section',result['fragment'])
        with self.assertRaises(ValueError):resolve_history(HISTORY,first['target'],'../../outside')

    def test_projection_inputs_are_preserved_sources_and_do_not_hash_outputs(self):
        root=make_fixture();apply_fixture(root)
        s7=WORK/'step7-projection-candidate'
        bindings=json.loads((s7/'ProjectionBindings.candidate.json').read_text(encoding='utf8'))
        cycle=PLAN['projection_cycle_prevention']
        for id,source in bindings['sources'].items():
            if id=='tool-routing':source['path']=cycle['tool_routing_input']['retained_path'];continue
            if id=='historical-status':source['path']=cycle['historical_status_input']['retained_path'];continue
            data=(WORK/source['path']).read_bytes()
            # Reuse exact previously retained fixture inputs if another active task has revised a source.
            if sha(data)!=source['sha256']:
                filename=id+('.json' if source['kind']=='json' else '.txt')
                matches=[p for p in s7.glob('fixture-*/'+filename) if sha(p.read_bytes())==source['sha256']]
                self.assertTrue(matches,'missing retained selected input '+id);data=matches[0].read_bytes()
            source['path']='_projection_inputs/'+id+('.json' if source['kind']=='json' else '.txt')
            write(root,source['path'],data)
        write(root,'_projection_inputs/bindings.json',json.dumps(bindings).encode('utf8'))
        output=root/'_projection_result';output.mkdir()
        code='''import {readFileSync,writeFileSync} from 'node:fs';import{resolve}from'node:path';
const p=await import(process.argv[1]);const root=process.argv[2],out=process.argv[3];
const b=JSON.parse(readFileSync(resolve(root,'_projection_inputs/bindings.json')));const m=p.buildModel(b,root);
const files=p.renderOutputs(m,readFileSync(resolve(root,b.sources['historical-status'].path)));
for(const[n,v]of Object.entries(files))writeFileSync(resolve(out,n),v);'''
        def generate():
            result=subprocess.run([NODE,'--input-type=module','-e',code,(s7/'project-governance.mjs').as_uri(),str(root),str(output)],capture_output=True,text=True)
            self.assertEqual(0,result.returncode,result.stderr)
            return {p.name:p.read_bytes() for p in output.iterdir()}
        first=generate()
        for name in ['README.md','AGENTS.md']:
            block=first['README.governance.md' if name=='README.md' else 'AGENTS.governance.md']
            self.assertTrue(ORIGINALS[name].endswith(b'\n'))
            write(root,name,ORIGINALS[name]+block)
            self.assertEqual(ORIGINALS[name],(root/name).read_bytes().split(b'<!-- BEGIN CLUED PHASE2 GOVERNANCE PROJECTION -->')[0])
        write(root,'CURRENT_STATUS.md',first['CURRENT_STATUS.projection.md'])
        second=generate();self.assertEqual(first,second)
        self.assertNotEqual(sha((root/'AGENTS.md').read_bytes()),bindings['sources']['tool-routing']['sha256'])
        self.assertEqual(sha((root/cycle['tool_routing_input']['retained_path']).read_bytes()),bindings['sources']['tool-routing']['sha256'])
        self.assertEqual(sha((root/cycle['historical_status_input']['retained_path']).read_bytes()),bindings['sources']['historical-status']['sha256'])
        receipt=after_receipt(root);restore_fixture(root,receipt)
        for name in ['README.md','AGENTS.md','CURRENT_STATUS.md']:self.assertEqual(ORIGINALS[name],(root/name).read_bytes())

if __name__=='__main__':
    stream=io.StringIO();result=unittest.TextTestRunner(stream=stream,verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(FixtureChecks))
    report={'scope':'ISOLATED_CANDIDATE_FIXTURES_ONLY','tests_run':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),'skipped':len(result.skipped),
      'source_commit':PLAN['source_commit'],'plan_sha256':sha((OUT/'MigrationPlan.candidate.json').read_bytes()),
      'test_sha256':sha(Path(__file__).read_bytes()),'real_repository_mutations':0,'formal_freeze_or_migration_issued':False,
      'details':stream.getvalue()}
    (OUT/'FixtureVerification.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
    print(json.dumps({k:v for k,v in report.items() if k!='details'},ensure_ascii=False))
    if not result.wasSuccessful():print(stream.getvalue())
    raise SystemExit(not result.wasSuccessful())
