"""Necessary executor checks; the existing nine compatibility tests are not rerun."""
import io
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import unittest

from migration_execute import MigrationError,execute,rollback,sha,encode,file_hash

HERE=Path(__file__).resolve().parent
REPO=HERE.parent/'phase2-governance-check'
ROOT_INPUTS=json.loads((HERE/'ExecutionInputs.candidate.json').read_text(encoding='utf8'))
FIXTURES=HERE/'fixtures';FIXTURES.mkdir(exist_ok=True)

def prepare():
    case=Path(tempfile.mkdtemp(prefix='executor-',dir=FIXTURES));repo=case/'repo';bundle=case/'bundle';repo.mkdir();bundle.mkdir()
    values=json.loads(json.dumps(ROOT_INPUTS))
    before={}
    for record in [*values['immutable_input_locks'],*[{'path':x['path'],'sha256':x['before_sha256']} for x in values['changes'] if x['before_sha256'] is not None]]:
        original=REPO/record['path'];raw=original.read_bytes()
        assert sha(raw)==record['sha256'],'real selected source changed: '+record['path']
        target=repo/record['path'];target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw)
        before[record['path']]=raw
    for item in values['changes']:
        if item['payload']:
            target=bundle/item['payload']['path'];target.parent.mkdir(parents=True,exist_ok=True)
            shutil.copyfile(HERE/item['payload']['path'],target)
    inputs=bundle/'ExecutionInputs.json';inputs.write_bytes(encode(values));input_sha=sha(inputs.read_bytes())
    architecture=bundle/'architecture.fixture.json';architecture.write_bytes(encode({'type':'ArchitectureConstitutionAcceptanceDecision','state':'ACCEPTED','fixture_scope_only':True}))
    freeze=bundle/'freeze.fixture.json';freeze.write_bytes(encode({'type':'Phase2StructureFreezeDecision','state':'FROZEN','fixture_scope_only':True,
      'migration_execution_inputs_ref':{'path':inputs.name,'sha256':input_sha},
      'architecture_acceptance_ref':architecture.name,'architecture_acceptance_digest':sha(architecture.read_bytes())}))
    return {'case':case,'repo':repo,'bundle':bundle,'inputs':inputs,'input_sha':input_sha,'freeze':freeze,'freeze_sha':sha(freeze.read_bytes()),'store':case/'transactions','before':before,'value':values}

def apply(case,**kwargs):return execute(case['repo'],case['inputs'],case['input_sha'],case['freeze'],case['freeze_sha'],case['store'],**kwargs)
def originals_match(test,case):
    for path,raw in case['before'].items():test.assertEqual(raw,(case['repo']/path).read_bytes(),path)
    for item in case['value']['changes']:
        if item['before_sha256'] is None:test.assertFalse((case['repo']/item['path']).exists(),item['path'])

class ExecutorTests(unittest.TestCase):
    def test_full_64_path_apply_and_manual_rollback_preserve_original_bytes_and_evidence(self):
        case=prepare();receipt=apply(case)
        self.assertEqual('MIGRATION_FILE_OPERATIONS_COMPLETED',receipt['status']);self.assertEqual(64,receipt['changed_paths'])
        for item in case['value']['changes']:self.assertEqual(item['after_sha256'],file_hash(case['repo']/item['path']))
        txn=Path(receipt['transaction']);self.assertEqual(29,len(list((txn/'backups').glob('*.bin'))))
        result=rollback(case['repo'],txn,case['input_sha'],case['freeze_sha'])
        self.assertEqual('ROLLED_BACK',result['status']);originals_match(self,case)
        self.assertTrue((txn/'receipt.json').is_file());self.assertTrue((txn/'events.jsonl').is_file())
        self.assertIn('ROLLBACK_COMPLETE',(txn/'events.jsonl').read_text(encoding='utf8'))
        self.assertFalse((case['repo']/'development').exists())

    def test_tampered_inputs_freeze_payload_source_or_existing_target_reject_before_mutation(self):
        for kind in ['inputs','freeze','payload','source','target','immutable_source']:
            with self.subTest(kind=kind):
                case=prepare()
                if kind=='inputs':case['inputs'].write_bytes(case['inputs'].read_bytes()+b' ')
                elif kind=='freeze':
                    v=json.loads(case['freeze'].read_bytes());v['state']='NOT_ISSUED';case['freeze'].write_bytes(encode(v));case['freeze_sha']=sha(case['freeze'].read_bytes())
                elif kind=='payload':
                    item=next(x for x in case['value']['changes'] if x['payload']);(case['bundle']/item['payload']['path']).write_bytes(b'payload tamper')
                elif kind=='source':
                    item=next(x for x in case['value']['changes'] if x['before_sha256']);(case['repo']/item['path']).write_bytes(b'concurrent source')
                elif kind=='immutable_source':
                    item=case['value']['immutable_input_locks'][0];(case['repo']/item['path']).write_bytes(b'changed contract')
                else:
                    item=next(x for x in case['value']['changes'] if x['before_sha256'] is None);path=case['repo']/item['path'];path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(b'occupied target')
                snapshot={p.relative_to(case['repo']).as_posix():p.read_bytes() for p in case['repo'].rglob('*') if p.is_file()}
                with self.assertRaises(MigrationError):apply(case)
                self.assertEqual(snapshot,{p.relative_to(case['repo']).as_posix():p.read_bytes() for p in case['repo'].rglob('*') if p.is_file()})

    def test_actual_partial_failure_automatically_restores_prior_files(self):
        case=prepare();result=apply(case,fail_after=4)
        self.assertTrue(result['apply_failed']);self.assertEqual('ROLLED_BACK',result['status']);originals_match(self,case)
        state=json.loads((Path(result['transaction'])/'state.json').read_bytes())
        self.assertEqual(4,len(state['applied']));self.assertEqual('ROLLED_BACK',state['status'])

    def test_abrupt_process_exit_keeps_originals_and_manual_recovery_works(self):
        case=prepare()
        code='''import os,sys
sys.path.insert(0,sys.argv[1])
from migration_execute import execute
def stop(index,txn):
 if index==2:os._exit(29)
execute(*sys.argv[2:],after_mutation=stop)
'''
        args=[str(case[k]) for k in ['repo','inputs','input_sha','freeze','freeze_sha','store']]
        result=subprocess.run([sys.executable,'-c',code,str(HERE),*args],capture_output=True,text=True)
        self.assertEqual(29,result.returncode,result.stderr)
        txn=next(case['store'].glob('migration-*'));state=json.loads((txn/'state.json').read_bytes())
        self.assertEqual('APPLYING',state['status']);self.assertEqual(3,len(state['applied']))
        result=rollback(case['repo'],txn,case['input_sha'],case['freeze_sha'])
        self.assertEqual('ROLLED_BACK',result['status']);originals_match(self,case)

    def test_concurrent_after_change_and_corrupt_backup_block_rollback_without_overwrite(self):
        for kind in ['after_change','backup']:
            with self.subTest(kind=kind):
                case=prepare();receipt=apply(case);txn=Path(receipt['transaction'])
                if kind=='after_change':
                    item=next(x for x in case['value']['changes'] if x['after_sha256']);(case['repo']/item['path']).write_bytes(b'new unrelated work')
                else:next((txn/'backups').glob('*.bin')).write_bytes(b'corrupt original backup')
                snapshot={p.relative_to(case['repo']).as_posix():p.read_bytes() for p in case['repo'].rglob('*') if p.is_file()}
                result=rollback(case['repo'],txn,case['input_sha'],case['freeze_sha'])
                self.assertEqual('ROLLBACK_BLOCKED',result['status'])
                self.assertEqual(snapshot,{p.relative_to(case['repo']).as_posix():p.read_bytes() for p in case['repo'].rglob('*') if p.is_file()})

if __name__=='__main__':
    stream=io.StringIO();result=unittest.TextTestRunner(stream=stream,verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(ExecutorTests))
    report={'scope':'NEW_EXECUTOR_ISOLATED_FIXTURES_ONLY','tests_run':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),'skipped':len(result.skipped),
      'executor_sha256':sha((HERE/'migration_execute.py').read_bytes()),'execution_inputs_sha256':sha((HERE/'ExecutionInputs.candidate.json').read_bytes()),
      'test_sha256':sha(Path(__file__).read_bytes()),'previous_nine_tests_repeated':False,'real_repository_writes':0,'actual_freeze_issued':False,'details':stream.getvalue()}
    (HERE/'ExecutorVerification.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
    print(json.dumps({k:v for k,v in report.items() if k!='details'},ensure_ascii=False))
    if not result.wasSuccessful():print(stream.getvalue())
    raise SystemExit(not result.wasSuccessful())
