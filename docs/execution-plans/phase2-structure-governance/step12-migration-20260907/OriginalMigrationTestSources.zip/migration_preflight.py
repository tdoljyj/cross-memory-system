"""Read-only migration/rollback preflight and original-commit link resolution."""
import argparse
import hashlib
import json
import posixpath
from pathlib import Path, PurePosixPath
from urllib.parse import unquote, urlsplit

def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def safe_path(root,name):
    if not isinstance(name,str) or not name or '\\' in name or '\0' in name:raise ValueError('invalid relative path')
    p=PurePosixPath(name)
    if p.is_absolute() or '..' in p.parts:raise ValueError('path traversal rejected')
    root=Path(root).resolve();target=root.joinpath(*p.parts)
    if not target.resolve().is_relative_to(root) or target.is_symlink():raise ValueError('path escapes root or is symlink')
    if p.parts[0] in ['memory','.git'] or name.startswith(('apps/','cloud/','artifacts/')):raise ValueError('protected migration path')
    return target

def preflight(plan,repo,payload_root):
    errors=[];sources={};targets={}
    for op in plan['operations']:
        s=op['source'];sources[s['path']]=s['sha256']
        if op['kind']=='MOVE_EXACT_BYTES':targets[op['target']]=op['expected_target_sha256']
        elif op['kind']=='PRESERVE_BASELINE_THEN_PROJECT':targets[op['archive_target']]=op['expected_archive_sha256']
        elif op['kind']=='MOVE_IMPLEMENTATION_WITH_COMPATIBILITY':
            targets[op['target_implementation']['path']]=op['target_implementation']['sha256']
            for field in ['target_implementation','compatibility_entry']:
                payload=op[field];p=safe_path(payload_root,payload['payload_path'])
                if not p.is_file() or digest(p)!=payload['sha256']:errors.append({'path':payload['path'],'reason':'PAYLOAD_DRIFT'})
        elif op['kind']=='UPDATE_SPECIFIC_CALLER_COPY_SET':
            payload=op['replacement'];p=safe_path(payload_root,payload['payload_path'])
            if not p.is_file() or digest(p)!=payload['sha256']:errors.append({'path':payload['path'],'reason':'PAYLOAD_DRIFT'})
        else:errors.append({'path':s['path'],'reason':'UNSUPPORTED_OPERATION'})
    for name,expected in sources.items():
        path=safe_path(repo,name)
        if not path.is_file():errors.append({'path':name,'reason':'SOURCE_MISSING'})
        elif digest(path)!=expected:errors.append({'path':name,'reason':'SOURCE_DRIFT','expected_sha256':expected,'actual_sha256':digest(path)})
    for name in targets:
        if safe_path(repo,name).exists():errors.append({'path':name,'reason':'TARGET_ALREADY_EXISTS'})
    return {'preflight':'CONCRETE_SOURCE_TARGETS_MATCH' if not errors else 'NOT_READY',
            'source_commit':plan['source_commit'],'source_files_checked':len(sources),'new_target_files_checked':len(targets),
            'errors':errors,'pending_freeze_bindings':plan['pending_freeze_bindings'],
            'execution_authorized_by_this_check':False,'actual_repository_writes':0,
            'boundary':'No move/apply command exists in this CLI. Valid Step11 and exact final bytes must be supplied by existing decision flow before a separate actual executor.'}

def rollback_preflight(receipt,repo):
    errors=[]
    for record in receipt['after_files']:
        path=safe_path(repo,record['path'])
        if record['sha256'] is None:
            if path.exists():errors.append({'path':record['path'],'reason':'EXPECTED_ABSENT_AFTER_MIGRATION'})
        elif not path.is_file() or digest(path)!=record['sha256']:
            errors.append({'path':record['path'],'reason':'AFTER_STATE_DRIFT_ROLLBACK_MUST_NOT_OVERWRITE'})
    return {'rollback_preflight':'EXACT_AFTER_STATE_MATCH' if not errors else 'BLOCKED_BY_DRIFT','errors':errors,
            'actual_repository_writes':0,'rollback_authorization_effect':'NONE','rule':'Restore only from bound originals and append a new rollback receipt; never erase prior evidence.'}

def resolve_history(history,source_path,href):
    entries=history['entries'];by_path={x['original']['path']:x for x in entries};by_target={x['target']:x for x in entries}
    entry=by_path.get(source_path) or by_target.get(source_path)
    if not entry:raise ValueError('source document not in exact history map')
    parsed=urlsplit(href)
    if parsed.scheme or parsed.netloc:return {'kind':'EXTERNAL_REFERENCE_UNCHANGED','reference':href}
    raw_path=unquote(parsed.path)
    if raw_path.startswith('/') or '\\' in raw_path:raise ValueError('absolute or platform-relative history link requires explicit source interpretation')
    target=entry['original']['path'] if not raw_path else posixpath.normpath(posixpath.join(posixpath.dirname(entry['original']['path']),raw_path))
    if target=='..' or target.startswith('../'):raise ValueError('history link escapes original repository')
    return {'kind':'ORIGINAL_COMMIT_RELATIVE_REFERENCE','commit':entry['original']['commit'],'original_target_path':target,
            'query':parsed.query,'fragment':parsed.fragment,'mapped_current_path':by_path[target]['target'] if target in by_path else None,
            'git_object_selector':entry['original']['commit']+':'+target,
            'reference_existence':'NOT_CLAIMED_BY_PATH_RESOLUTION; verify the exact Git object when consumed',
            'historical_bytes_rewritten':False}

def main():
    p=argparse.ArgumentParser();sub=p.add_subparsers(dest='mode',required=True)
    q=sub.add_parser('preflight');q.add_argument('--plan',required=True);q.add_argument('--repo',required=True);q.add_argument('--payload-root',required=True)
    q=sub.add_parser('rollback-preflight');q.add_argument('--receipt',required=True);q.add_argument('--repo',required=True)
    q=sub.add_parser('resolve-history');q.add_argument('--map',required=True);q.add_argument('--source',required=True);q.add_argument('--href',required=True)
    a=p.parse_args()
    try:
        if a.mode=='preflight':result=preflight(json.loads(Path(a.plan).read_text(encoding='utf8')),a.repo,a.payload_root)
        elif a.mode=='rollback-preflight':result=rollback_preflight(json.loads(Path(a.receipt).read_text(encoding='utf8')),a.repo)
        else:result=resolve_history(json.loads(Path(a.map).read_text(encoding='utf8')),a.source,a.href)
        print(json.dumps(result,ensure_ascii=False));return 1 if result.get('errors') else 0
    except (ValueError,KeyError,OSError) as error:
        print(json.dumps({'status':'PREFLIGHT_INVALID','error':str(error),'actual_repository_writes':0},ensure_ascii=False));return 1
if __name__=='__main__':raise SystemExit(main())
