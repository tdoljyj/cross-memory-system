import hashlib
import json
import shutil
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

HERE = Path(__file__).resolve().parent
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
def read(path):
    return json.loads(path.read_text(encoding='utf-8'))
def write(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')

results = read(HERE/'TestResults.json')
real_source = HERE/'fixtures/real_candidate_binding_qualification/Receipt.json'
shutil.copyfile(real_source, HERE/'RealCandidateEvidence.json')
real = read(real_source)
types = read(HERE/'PositiveTypeCoverage.json')
statuses = Counter(row['status'] for row in real['reference_observations'])
rules = '\n'.join('| '+row['baseline_type']+' | '+row['rule']+' | '+row['scope']+' |' for row in types['types'])
negative = '\n'.join('| '+row['case']+' | '+str(row['process_exit_code'])+' | '+str(row['target_rule'])+' |' for row in results['cases'] if row['case'].startswith('N'))
text = f'''# Step 8 有界 Validator 实施候选

状态：**VERIFIED：23 / 23 次真实 CLI 调用符合预期；candidate，未签 Step 8 接受、未发行 Freeze。**

入口为 `naming_validator.py`。它读取 Step 4 / 5 原候选、Step 6 的原始矩阵和补充类型化引用链，以及 Step 7 的实际 selector / generator；没有创建第二份业务运行 schema 或 SSOT。输入摘要、源 JSON Pointer、错误规则、真实进程退出码与每次运行身份均保留在回执。

`RealCandidateEvidence.json` 是最后测试中真实输入的原回执副本，run_id `{real['run_id']}`，exit 0，scoped_step6_bindings_qualified=true，绑定缺口 0。它验证的是当前源保持不变的结构/naming 范围；`formal_step8_gate=false`、`freeze_ready=false`。CLI 的 `--purpose freeze` 仅额外检查核心绑定齐备，**不签署 Step 11 Freeze**。删除实际消费者的 domain_id 后，同一严格检查返回 exit 1 / FREEZE_BINDING。

这次沿用纠正后的 C01：initialize 缺 Bearer 为 401，setup 只检查 Bearer 存在；tools/list/bootstrap 可匿名。额外负例将该前置改为 false，被 AUTHORIZATION_SCOPE 拒绝。未发起新登录或服务调用。C09 原有 export 声明/执行 scope 差异按现有独立 disposition 保留，不能读成双 scope PASS；不因它阻断无关命名路径。

最终源观测 {len(real['source_observations'])} 项；引用解析记录 {len(real['reference_observations'])} 条（会包含重复引用）。其中 {statuses['VERIFIED_SOURCE_HASH_AND_POINTER']} 条为重算来源摘要后的 JSON Pointer 解析，{statuses['DOCUMENTED_PROSE_LOCATOR_NOT_MACHINE_RESOLVED']} 条只保留为文档定位。完整 246 MB ZIP 摘要继承先前独立验证，本次没有重复重算；实际读取的 ZIP 小成员均自行重算摘要。

## 正例类型与实际证明范围

13 类在一个明确标注 fixture_only 的隔离候选中实际运行。唯一新 alias 是测试夹具，只指向原有 source-bound 类型定义，没有装入真实 registry。真实 alias 列表为空；不能由正例声称线上 alias 已启用。typed runtime ID 是既有请求时解析槽，不能读成新运行证据。

| 基线正例类型 | 实际规则 | 证明范围 |
|---|---|---|
{rules}

## 16 个基线负例

全部调用真实 CLI、读取真实隔离文件并断言对应错误码；不是 mock 或脚本自行宣称失败。测试更新隔离输入摘要后才注入语义错误，避免只靠坏 hash 偶然红灯；来源漂移另外单独测试。README / pending / unexecuted 负例修改真实生成文件，并复用原 Step 7 renderer 检查。

| 隔离用例 | 实际退出码 | 必须出现的目标规则 |
|---|---:|---|
{negative}

额外检查：真实18消费者绑定就绪；来源摘要漂移；缺核心身份拒绝严格绑定检查；C01 Bearer 前置升级；跨消费者 Auth 引用；旧 CI receipt 缺 candidate subject。总计 23 次 CLI 调用，8 个 unittest 方法，最后一次实际运行约 21 秒。

## 复跑与采用条件

在当前工程工作目录，使用本机既有 Python：

```powershell
& 'C:/Users/Windows/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe' work/step8-validator/test_validator.py
& 'C:/Users/Windows/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe' work/step8-validator/naming_validator.py --bindings work/step8-validator/InputBindings.candidate.json --source-root work --purpose evidence --report work/step8-validator/NextRealCandidateEvidence.json
```

输入变化时先审查变化，再运行 prepare_bindings.py 刷新**路径与摘要选择**；这个动作不等于接受变化。当前 TestResults 仅绑定本次精确输入。Step 7 尚是原候选生成目录，Step5/6 Decision 接线和正式 typed consumer selector 应由其负责方完成；CLI 对现有 matrix 或补充 typed consumer 的精确来源选择均可验证。正式接线或迁移后，只重跑受影响的输入/投影检查并保留新回执。

实现的规则适配这些已读过的既有候选格式和 C01 实际源码，未冒称通用 TypeScript 权限解释器。当前源码无法解析为已知前置时拒绝该绑定并要求局部审查。对 protected 服务的全部权限语义、未触及的 future commercial domains、Step 13 迁移后兼容、Step 16 新四 Gate、Step 18 强制门禁均没有用夹具绿灯代替。完整包、生产状态和已可靠证据不为本次候选重新审计。

证据入口：`TestResults.json`（23次命令/退出码/目标规则/回执摘要）、`PositiveTypeCoverage.json`、`InputBindings.candidate.json`、`RealCandidateEvidence.json`、各 `fixtures/<case>/` 的实际输入、生成输出、stdout/stderr/Receipt。`EvidenceIndex.json` 只索引最终证据集；早期的 BeforeC01Correction 或旧 real_candidate_freeze 试跑不作为本结论依据。

源码 SHA256：`naming_validator.py` = `{sha(HERE/'naming_validator.py')}`。全部文件只在 work/step8-validator；没有修改仓库源文件、提交、push、生产或 Canonical 数据。
'''
(HERE/'Result.md').write_text(text, encoding='utf-8')
files = [HERE/name for name in ('naming_validator.py','test_validator.py','projection-check.mjs','fixture-render.mjs',
    'prepare_bindings.py','finalize_evidence.py','InputBindings.candidate.json','TestResults.json','PositiveTypeCoverage.json',
    'RealCandidateEvidence.json','Result.md')]
for case in results['cases']:
    files.extend(path for path in (HERE/Path(case['receipt']).parent).rglob('*') if path.is_file())
unique = sorted(set(files))
write(HERE/'EvidenceIndex.json', {'status':'FINAL_RETAINED_CANDIDATE_EVIDENCE',
    'created_at_utc':datetime.now(timezone.utc).isoformat(), 'formal_step8_gate':False,
    'case_count':len(results['cases']), 'source_subject_sha256':real['subject']['sha256'],
    'files':[{'path':str(path.relative_to(HERE)), 'bytes':path.stat().st_size, 'sha256':sha(path),
              'digest_recomputed':True} for path in unique]})
print(json.dumps({'status':results['status'], 'cases':len(results['cases']), 'evidence_files':len(unique),
                  'references':len(real['reference_observations']), 'source_observations':len(real['source_observations']),
                  'Result':str(HERE/'Result.md')}, ensure_ascii=False))
