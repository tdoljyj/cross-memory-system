"""Real subprocess, retained isolated candidate bytes, target-rule assertions; no mocked verdicts."""
import copy
import hashlib
import json
import shutil
import subprocess
import sys
import unittest
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
BASE = json.loads((HERE / 'InputBindings.candidate.json').read_text(encoding='utf-8'))
RESULTS = []


def write(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def fixture(name, mutate=None, projection_mutate=None, populated_alias=False):
    folder = HERE / 'fixtures' / name
    folder.mkdir(parents=True, exist_ok=True)
    binding = copy.deepcopy(BASE)
    binding['fixture_only'] = True
    data = {}
    # Each case has independent bytes; never edit any actual Step 4/5/6/7 input.
    for role, selected in binding['inputs'].items():
        source = ROOT / selected['path']
        if selected['kind'] == 'json':
            path = folder / (role + '.json')
            shutil.copyfile(source, path)
            data[role] = json.loads(path.read_text(encoding='utf-8-sig'))
            selected['path'] = str(path.relative_to(ROOT))
    if populated_alias:
        target = data['logical']['identity_types'][0]
        data['aliases']['new_runtime_alias_entries'] = [{
            'alias': 'fixture_read_only_artifact_revision',
            'namespace_or_contract': target['namespace'], 'canonical_target': target['type'],
            'read_only_compatibility': True, 'new_writes_allowed': False,
            'lifecycle': 'ISOLATED_VALIDATOR_FIXTURE_ONLY', 'retirement_conditions': 'Never installed; discard after test.',
            'reverse_resolution': target['type'], 'ambiguity_disposition': 'reject',
            'source_evidence': target['source_ref']}]
    if mutate:
        mutate(data)
    # Point the one existing Step 7 renderer at the exact selected fixture candidates.
    for role, source_id in {'ownership':'namespace', 'versions':'versions', 'aliases':'aliases',
                            'consumers':'consumers', 'identity_policy':'identity-policy',
                            'review_subject':'review-subject'}.items():
        selected = binding['inputs'][role]
        path = ROOT / selected['path']
        write(path, data[role])
        data['projection_bindings']['sources'][source_id].update(path=selected['path'], sha256=sha(path))
    for role, value in data.items():
        path = ROOT / binding['inputs'][role]['path']
        write(path, value)
        binding['inputs'][role]['sha256'] = sha(path)
    output = folder / 'generated'
    rendered = subprocess.run([binding['node'], str(HERE/'fixture-render.mjs'),
                               str(ROOT/binding['inputs']['projection_generator']['path']),
                               str(ROOT/binding['inputs']['projection_bindings']['path']), str(ROOT), str(output)],
                              capture_output=True, text=True, encoding='utf-8')
    if rendered.returncode:
        raise AssertionError('fixture rendering failed: ' + rendered.stderr)
    if projection_mutate:
        projection_mutate(output)
    binding['projection_output'] = str(output.relative_to(ROOT))
    write(folder/'InputBindings.json', binding)
    return folder


def invoke(folder, expected, target=None, purpose='evidence', binding=None):
    binding = binding or folder/'InputBindings.json'
    command = [sys.executable, str(HERE/'naming_validator.py'), '--bindings', str(binding),
               '--source-root', str(ROOT), '--purpose', purpose, '--report', str(folder/'Receipt.json')]
    result = subprocess.run(command, capture_output=True, text=True, encoding='utf-8', timeout=60)
    (folder/'stdout.txt').write_text(result.stdout, encoding='utf-8')
    (folder/'stderr.txt').write_text(result.stderr, encoding='utf-8')
    report = json.loads((folder/'Receipt.json').read_text(encoding='utf-8'))
    codes = [row['code'] for row in report['errors']]
    entry = {'case': folder.name, 'purpose': purpose, 'process_exit_code': result.returncode,
             'expected_exit_code': expected, 'target_rule': target, 'observed_error_codes': codes,
             'target_rule_failed': target in codes if target else None,
             'receipt': str((folder/'Receipt.json').relative_to(HERE)), 'receipt_sha256': sha(folder/'Receipt.json'),
             'fixture_bindings_sha256': sha(binding), 'command': command,
             'passed': result.returncode == expected and (target is None or target in codes)}
    RESULTS.append(entry)
    assert result.returncode == expected, entry
    if target:
        assert target in codes, entry
        assert 'INVALID_INPUT' not in codes, 'target error was only malformed test setup'
    return report


class ValidatorIntegrationTests(unittest.TestCase):
    def test_positive_13_types(self):
        report = invoke(fixture('positive_13_types', populated_alias=True), 0)
        self.assertFalse(report['freeze_ready'])
        self.assertFalse(report['formal_step8_gate'])
        self.assertTrue(report['fixture_only'])
        coverage = {'canonical_name':'CANONICAL_IDENTITY', 'namespace_ownership':'OWNER',
                    'alias_resolution':'ALIAS_RESOLUTION', 'logical_object_identity':'CANONICAL_IDENTITY',
                    'representation':'REPRESENTATION_CANONICAL', 'copy_identity':'COPY_ORIGINAL',
                    'version_axis':'VERSION_AXIS', 'typed_receipts':'RECEIPT_SUBJECT',
                    'typed_authorization':'AUTHORIZATION_SCOPE', 'typed_consumers':'CONSUMER_NAMESPACE',
                    'deterministic_projections':'PROJECTION_DRIFT', 'direct_predecessor':'PREDECESSOR',
                    'current_historical_distinction':'CURRENT_HISTORICAL'}
        checks = {row['rule']: row for row in report['checks']}
        for category, rule in coverage.items():
            self.assertEqual(checks[rule]['status'], 'PASS', category)
        write(HERE/'PositiveTypeCoverage.json', {'status':'13_BOUNDED_POSITIVE_TYPES_EXECUTED',
              'fixture_only': True, 'formal_step8_gate': False,
              'types': [{'baseline_type': category, 'rule': rule, 'scope': checks[rule]['scope']} for category, rule in coverage.items()]})

    def test_negative_16(self):
        def bad_owner(d):
            del d['ownership']['namespaces'][0]['management_owner']
        def collision(d):
            row = copy.deepcopy(d['logical']['identity_types'][0])
            row['source_ref'] = copy.deepcopy(d['logical']['identity_types'][1]['source_ref'])
            d['logical']['identity_types'].append(row)
        def multiple(d):
            row = copy.deepcopy(d['logical']['identity_types'][0])
            row['type'] += '_second_canonical'
            d['logical']['identity_types'].append(row)
        def historical(d):
            d['current_registry']['artifacts'][0]['path'] = 'archives/forbidden_current.json'
        def axis(d):
            next(r for r in d['versions']['axes'] if r['axis']=='architecture')['observed_or_reserved_identity'] = 'v0.2.7.1'
        def auth(d):
            d['namespace_delegation']['delegations'][0]['namespace_group_refs'].append(
                {'file':'NamespaceOwnershipManifest.candidate.json', 'group_key':'UNAUTHORIZED_NAMESPACE'})
        def representation(d):
            next(r for r in d['representation']['representations'] if r['kind']=='human_projection')['canonical_for_business_state'] = True
        def readme(output):
            path = output/'README.governance.md'
            path.write_text(path.read_text(encoding='utf-8')+'\nOwner: fixture_intruder\n', encoding='utf-8')
        def projected(output, edit):
            path = output/'GovernanceManifest.projection.json'
            value = json.loads(path.read_text(encoding='utf-8'))
            edit(value)
            write(path, value)
        cases = [
            ('N01_missing_namespace_owner', 'OWNER', bad_owner, None, False),
            ('N02_same_name_different_objects', 'CANONICAL_COLLISION', collision, None, False),
            ('N03_one_object_multiple_canonical', 'MULTIPLE_CANONICAL', multiple, None, False),
            ('N04_alias_missing_target', 'ALIAS_TARGET', lambda d:d['aliases']['new_runtime_alias_entries'][0].update(canonical_target='DOES_NOT_EXIST'), None, True),
            ('N05_alias_new_write', 'ALIAS_WRITE', lambda d:d['aliases']['new_runtime_alias_entries'][0].update(new_writes_allowed=True), None, True),
            ('N06_current_uses_historical', 'CURRENT_HISTORICAL', historical, None, False),
            ('N07_wrong_direct_predecessor', 'PREDECESSOR', lambda d:d['versions']['direct_predecessor']['source_ref'].update(pointer='/subject'), None, False),
            ('N08_mixed_version_axis', 'VERSION_AXIS', axis, None, False),
            ('N09_receipt_missing_subject', 'RECEIPT_SUBJECT', lambda d:d['typed_receipts']['bindings'][0].pop('subject'), None, False),
            ('N10_authorization_scope_escalation', 'AUTHORIZATION_SCOPE', auth, None, False),
            ('N11_consumer_unauthorized_namespace', 'CONSUMER_NAMESPACE', lambda d:d['typed_consumers']['consumers'][0].update(accepted_namespace='/unauthorized/namespace'), None, False),
            ('N12_readme_registry_disagreement', 'PROJECTION_DRIFT', None, readme, False),
            ('N13_copy_claims_original', 'COPY_ORIGINAL', lambda d:d['copy'].update(independent_write_authority=True), None, False),
            ('N14_representation_claims_canonical', 'REPRESENTATION_CANONICAL', representation, None, False),
            ('N15_pending_projected_accepted', 'PENDING_ACCEPTED', None, lambda o:projected(o,lambda v:v['facts']['step5_candidate_status'].update(value='ACCEPTED')), False),
            ('N16_unexecuted_projected_pass', 'UNEXECUTED_PASS', None, lambda o:projected(o,lambda v:v['facts']['consumer_bindings']['value'][0].update(evidence_status='PASS')), False),
        ]
        for name, rule, mutate, projection_mutate, alias in cases:
            with self.subTest(name=name):
                invoke(fixture(name, mutate, projection_mutate, alias), 1, rule)

    def test_input_digest_rejection(self):
        folder = fixture('extra_source_digest_drift')
        path = folder/'copy.json'
        path.write_bytes(path.read_bytes()+b' ')
        invoke(folder, 1, 'SOURCE_DIGEST')

    def test_actual_per_consumer_bindings_qualify(self):
        folder = HERE/'fixtures/real_candidate_binding_qualification'
        folder.mkdir(parents=True, exist_ok=True)
        report = invoke(folder, 0, None, 'freeze', HERE/'InputBindings.candidate.json')
        self.assertFalse(report['fixture_only'])
        self.assertFalse(report['step6_binding_gaps'])
        self.assertFalse(report['freeze_ready'])

    def test_missing_core_identity_rejects_freeze_prerequisites(self):
        folder = fixture('extra_missing_core_identity', lambda d:d['typed_consumers']['consumers'][0].pop('domain_id'))
        report = invoke(folder, 1, 'FREEZE_BINDING', 'freeze')
        self.assertTrue(report['step6_binding_gaps'])

    def test_typed_public_auth_cannot_bypass_actual_initialize_challenge(self):
        def mutate(d):
            row = next(r for r in d['typed_authorization']['bindings'] if r['consumer_id']=='C01' and r['profile']=='public')
            next(p for p in row['operation_policy'] if p['operation']=='initialize')['requires_bearer_presence'] = False
        invoke(fixture('extra_public_initialize_escalation', mutate), 1, 'AUTHORIZATION_SCOPE')

    def test_typed_auth_cross_consumer_rejected(self):
        def mutate(d):
            row = d['typed_consumers']['consumers'][0]
            row['required_authorization'] = copy.deepcopy(d['typed_consumers']['consumers'][1]['required_authorization'])
        invoke(fixture('extra_cross_consumer_authorization', mutate), 1, 'AUTHORIZATION_SCOPE')

    def test_historical_ci_receipt_missing_subject_rejected(self):
        invoke(fixture('extra_historical_ci_missing_subject', lambda d:d['ci_receipt'].pop('candidate')), 1, 'RECEIPT_SUBJECT')


if __name__ == '__main__':
    suite = unittest.defaultTestLoader.loadTestsFromTestCase(ValidatorIntegrationTests)
    outcome = unittest.TextTestRunner(verbosity=2).run(suite)
    write(HERE/'TestResults.json', {'status':'PASS' if outcome.wasSuccessful() else 'FAIL',
          'subprocess_cases':len(RESULTS), 'cases_passed':sum(row['passed'] for row in RESULTS),
          'negative_baseline_cases':16, 'positive_baseline_types':13, 'formal_step8_gate':False,
          'fixture_green_is_not_real_freeze':True, 'cases':RESULTS})
    sys.exit(0 if outcome.wasSuccessful() else 1)
