<!-- BEGIN CLUED PHASE2 GOVERNANCE PROJECTION -->

本区块由已绑定的治理来源生成；候选、未定和历史状态保持原含义。它不授予权限，不写入业务 Canon，不宣告接受、冻结或实现。

来源集合摘要：`a746a5c1a8d78adc13c0328c6f2f7add1a6716d9c43bf95b80e33a6b9cb75d4b`；事实模型摘要：`a0aca0e16246c6209b31576bb8a9828dbe47eacb9fa9e18e631935c94327df4c`。

| 治理事实 | 来源值 |
|---|---|
| 投影性质 | PREPARATION_ONLY_NOT_STEP7_GATE |
| Step 4 原状态 | PREPARATION_ONLY_NOT_STEP4_ACCEPTANCE |
| 管理 Owner（仅任务管理） | current Clued project owner in the authenticated user conversation |
| Namespace 候选组数 | 10 |
| Step 5 原状态 | PREPARATION_ONLY_NOT_STEP5_ACCEPTANCE |
| 稳定 Map | CANDIDATE_TARGET_MAP_V0_1_1 |
| 本候选新增 Alias 数 | 1 |
| 架构直接前序（原引用对象） | {"axis":"architecture","bytes":168491377,"filename":"Clued_Phase2_三项设计候选_完整审查包_v0.2.4_20260905.zip","members":440,"sha256":"4aae92c37813772e983a14537be52ca8b428af666e644b72d40084ccd592d68b","version":"v0.2.4"} |
| 历史命名空间不得签发当前状态 | true |
| Step 6 原状态 | PREPARATION_ONLY_NOT_STEP6_PASS |
| 正式 Domain / Program / Stage | [null,null,null] |
| 消费者准备行数（不等于已接线数） | 18 |
| Step 4 / 5 / 6 Decision 来源状态 | ["ACCEPTED_FOR_STEP4_ADMINISTRATIVE_SCOPE","UNBOUND","UNBOUND"] |
| 已选上游引用一致性 | SELECTED_LINEAGE_MATCHES |

| 版本轴 | 来源身份 |
|---|---|
| product | Clued-v1.6 |
| architecture | v0.2.5 |
| mapping | v0.1.1 |
| schema | {"core_definition":"1.0.0-local-rc-v15","model_schema_definition":"2.0.0-local-rc-v15-model"} |
| artifact | per-entry path/bytes/sha256 |
| skill | v0.1.5 |
| runtime | null |
| candidate_revision | v0.2.7.1 |
| migration_revision | null |
| protocol | {"definition_version":"1.0.0-local-rc-v15","path_namespace":"protocol/continuity/v1","schema_version":"clued.protocol-manifest/1"} |

未绑定 Decision 不被解释为接受；无实际消费者证据的准备行不被解释为运行接线完成。新增 Alias 为零不证明历史或外部别名已经全量枚举。

<!-- END CLUED PHASE2 GOVERNANCE PROJECTION -->
