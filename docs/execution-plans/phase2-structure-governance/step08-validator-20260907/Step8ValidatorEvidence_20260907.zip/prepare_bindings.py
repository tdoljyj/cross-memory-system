"""Select actual existing files; this file does not assign any business identities."""
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
REPO = ROOT / 'phase2-governance-check'
GOV = REPO / 'docs/execution-plans/phase2-structure-governance'
STEP4 = GOV / 'step04-namespace-20260907'
STEP5 = ROOT / 'step5-identity-candidate'
STEP7 = ROOT / 'step7-projection-candidate'
sources = {
    'ownership': STEP4 / 'NamespaceOwnershipManifest.candidate.json',
    'namespace_delegation': STEP4 / 'NamespaceDelegationManifest.candidate.json',
    'step4_sources': STEP4 / 'Sources.json',
    'step5_sources': STEP5 / 'Sources.json',
    'logical': STEP5 / 'LogicalObjectIdentityContract.candidate.json',
    'aliases': STEP5 / 'AliasRegistry.candidate.json',
    'copy': STEP5 / 'CopyIdentityContract.candidate.json',
    'representation': STEP5 / 'RepresentationContract.candidate.json',
    'versions': STEP5 / 'VersionAxisRegistry.candidate.json',
    'consumers': ROOT / 'step6-consumer-candidate/ConsumerMatrix.json',
    'current_registry': REPO / 'artifacts/clued-validation/structure-freeze-prep/acceptance-20260907/step2/package-inputs/data/CurrentArtifactRegistry.json',
    'identity_policy': STEP7 / 'inputs/CurrentArtifactIdentityPolicy.json',
    'review_subject': STEP7 / 'inputs/ReviewSubjectContract.json',
    'ci_receipt': REPO / 'artifacts/clued-validation/structure-freeze-prep/acceptance-20260907/step1/34069116734/CIGateReceipt.json',
    'worker_source': REPO / 'apps/clued-cloud/worker/continuity.ts',
    'projection_bindings': STEP7 / 'ProjectionBindings.candidate.json',
    'projection_generator': STEP7 / 'project-governance.mjs',
    'typed_consumers': ROOT / 'step6-bindings/TypedConsumerRegistry.candidate.json',
    'typed_authorization': ROOT / 'step6-bindings/TypedAuthorizationRegistry.candidate.json',
    'typed_receipts': ROOT / 'step6-bindings/TypedReceiptRegistry.candidate.json',
    'step6_sources': ROOT / 'step6-bindings/SourceIndex.json',
    'export_scope_disposition': ROOT / 'step6-bindings/C09ExportScopeDisposition.json',
}
node = Path('C:/Program Files/nodejs/node.exe')
if not node.exists():
    node = Path('C:/Users/Windows/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node.exe')
bindings = {'format': 'STEP8_SOURCE_LOCATORS_ONLY', 'authority_effect': 'NONE', 'fixture_only': False,
            'node': str(node), 'projection_output': str((STEP7 / 'generated').relative_to(ROOT)),
            'inputs': {role: {'path': str(path.relative_to(ROOT)),
                             'kind': 'json' if path.suffix == '.json' else 'text',
                             'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}
                       for role, path in sources.items()}}
target = HERE / 'InputBindings.candidate.json'
target.write_text(json.dumps(bindings, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
print(target)
